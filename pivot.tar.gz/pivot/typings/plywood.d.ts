/// <reference path="../node_modules/plywood/build/plywood.d.ts" />
/// <reference path="../node_modules/plywood-druid-requester/build/plywood-druid-requester.d.ts" />
/// <reference path="../node_modules/plywood-mysql-requester/build/plywood-mysql-requester.d.ts" />
