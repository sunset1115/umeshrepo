// Type definitions for React v0.13.3
// Project: http://facebook.github.io/react/
// Definitions by: Vadim
// Definitions: https://github.com/borisyankov/DefinitelyTyped

declare module "react-addons-css-transition-group" {
  var v: any;
  export = v;
}
