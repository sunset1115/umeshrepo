declare module "express-handlebars" {
  var p: any;
  export = p;
}
