# How to Contribute

If you have questions about Imply Pivot, please direct them to our [user group](https://groups.google.com/forum/#!forum/imply-user-group).
We are not accepting pull requests at the moment, but will do so once the project is in beta. 

