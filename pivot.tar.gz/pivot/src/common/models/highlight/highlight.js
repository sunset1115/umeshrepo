"use strict";
var immutable_class_1 = require('immutable-class');
var filter_1 = require('../filter/filter');
var check;
var Highlight = (function () {
    function Highlight(parameters) {
        var owner = parameters.owner;
        if (typeof owner !== 'string')
            throw new TypeError('owner must be a string');
        this.owner = owner;
        this.delta = parameters.delta;
    }
    Highlight.isHighlight = function (candidate) {
        return immutable_class_1.isInstanceOf(candidate, Highlight);
    };
    Highlight.fromJS = function (parameters) {
        return new Highlight({
            owner: parameters.owner,
            delta: filter_1.Filter.fromJS(parameters.delta)
        });
    };
    Highlight.prototype.valueOf = function () {
        return {
            owner: this.owner,
            delta: this.delta
        };
    };
    Highlight.prototype.toJS = function () {
        return {
            owner: this.owner,
            delta: this.delta.toJS()
        };
    };
    Highlight.prototype.toJSON = function () {
        return this.toJS();
    };
    Highlight.prototype.toString = function () {
        return "[Highlight " + this.owner + "]";
    };
    Highlight.prototype.equals = function (other) {
        return Highlight.isHighlight(other) &&
            this.owner === other.owner &&
            this.delta.equals(other.delta);
    };
    Highlight.prototype.applyToFilter = function (filter) {
        return filter.applyDelta(this.delta);
    };
    Highlight.prototype.constrainToDimensions = function (dimensions, timeAttribute) {
        var delta = this.delta;
        var newDelta = delta.constrainToDimensions(dimensions, timeAttribute);
        if (newDelta === delta)
            return this;
        if (newDelta.length() === 0)
            return null;
        var value = this.valueOf();
        value.delta = newDelta;
        return new Highlight(value);
    };
    return Highlight;
}());
exports.Highlight = Highlight;
check = Highlight;
//# sourceMappingURL=highlight.js.map