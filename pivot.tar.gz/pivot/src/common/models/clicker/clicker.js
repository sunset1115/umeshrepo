"use strict";
//# sourceMappingURL=clicker.js.map