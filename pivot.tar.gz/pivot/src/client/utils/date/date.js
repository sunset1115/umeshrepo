"use strict";
var d3 = require('d3');
var chronoshift_1 = require('chronoshift');
var formatWithYear = d3.time.format('%b %-d, %Y');
var formatWithoutYear = d3.time.format('%b %-d');
var formatTimeOfDayWithoutMinutes = d3.time.format('%-I%p');
var formatTimeOfDayWithMinutes = d3.time.format('%-I:%M%p');
function formatTimeOfDay(d) {
    return d.getMinutes() ? formatTimeOfDayWithMinutes(d) : formatTimeOfDayWithoutMinutes(d);
}
function isCurrentYear(year, timezone) {
    var nowWallTime = chronoshift_1.WallTime.UTCToWallTime(new Date(), timezone.toString());
    return nowWallTime.getFullYear() === year;
}
(function (DisplayYear) {
    DisplayYear[DisplayYear["ALWAYS"] = 0] = "ALWAYS";
    DisplayYear[DisplayYear["NEVER"] = 1] = "NEVER";
    DisplayYear[DisplayYear["IF_DIFF"] = 2] = "IF_DIFF";
})(exports.DisplayYear || (exports.DisplayYear = {}));
var DisplayYear = exports.DisplayYear;
function formatTimeRange(timeRange, timezone, displayYear) {
    var start = timeRange.start, end = timeRange.end;
    var startWallTime = chronoshift_1.WallTime.UTCToWallTime(start, timezone.toString());
    var endWallTime = chronoshift_1.WallTime.UTCToWallTime(end, timezone.toString());
    var endShiftWallTime = chronoshift_1.WallTime.UTCToWallTime(new Date(end.valueOf() - 1), timezone.toString());
    var showingYear = true;
    var formatted;
    if (startWallTime.getFullYear() !== endShiftWallTime.getFullYear()) {
        formatted = [formatWithYear(startWallTime), formatWithYear(endShiftWallTime)].join(' - ');
    }
    else {
        showingYear = displayYear === DisplayYear.ALWAYS || (displayYear === DisplayYear.IF_DIFF && !isCurrentYear(endShiftWallTime.getFullYear(), timezone));
        var fmt = showingYear ? formatWithYear : formatWithoutYear;
        if (startWallTime.getMonth() !== endShiftWallTime.getMonth() || startWallTime.getDate() !== endShiftWallTime.getDate()) {
            formatted = [formatWithoutYear(startWallTime), fmt(endShiftWallTime)].join(' - ');
        }
        else {
            formatted = fmt(startWallTime);
        }
    }
    if (startWallTime.getHours() || startWallTime.getMinutes() || endWallTime.getHours() || endWallTime.getMinutes()) {
        formatted += (showingYear ? ' ' : ', ');
        var startTimeStr = formatTimeOfDay(startWallTime).toLowerCase();
        var endTimeStr = formatTimeOfDay(endWallTime).toLowerCase();
        if (startTimeStr === endTimeStr) {
            formatted += startTimeStr;
        }
        else {
            if (startTimeStr.substr(-2) === endTimeStr.substr(-2)) {
                startTimeStr = startTimeStr.substr(0, startTimeStr.length - 2);
            }
            formatted += [startTimeStr, endTimeStr].join('-');
        }
    }
    return formatted;
}
exports.formatTimeRange = formatTimeRange;
//# sourceMappingURL=date.js.map