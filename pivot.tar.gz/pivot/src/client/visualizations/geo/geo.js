"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./geo.css');
var React = require('react');
// import { ... } from '../../config/constants';
var index_1 = require('../../../common/models/index');
var Geo = (function (_super) {
    __extends(Geo, _super);
    function Geo() {
        _super.call(this);
        // this.state = {};
    }
    Geo.handleCircumstance = function (dataSource, splits, colors, current) {
        return index_1.Resolve.manual(0, 'The Geo visualization is not ready, please select another visualization.', []);
    };
    Geo.prototype.componentDidMount = function () {
        this.mounted = true;
    };
    Geo.prototype.componentWillUnmount = function () {
        this.mounted = false;
    };
    Geo.prototype.componentWillReceiveProps = function (nextProps) {
    };
    Geo.prototype.render = function () {
        return <div className="geo"></div>;
    };
    Geo.id = 'geo';
    Geo.title = 'Geo';
    return Geo;
}(React.Component));
exports.Geo = Geo;
//# sourceMappingURL=geo.js.map