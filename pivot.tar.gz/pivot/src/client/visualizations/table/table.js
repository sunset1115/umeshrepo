"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./table.css');
var immutable_1 = require('immutable');
var React = require('react');
var ReactDOM = require('react-dom');
var plywood_1 = require('plywood');
var formatter_1 = require('../../../common/utils/formatter/formatter');
var index_1 = require('../../../common/models/index');
var constants_1 = require('../../config/constants');
var dom_1 = require('../../utils/dom/dom');
var svg_icon_1 = require('../../components/svg-icon/svg-icon');
var highlight_controls_1 = require('../../components/highlight-controls/highlight-controls');
var loader_1 = require('../../components/loader/loader');
var query_error_1 = require('../../components/query-error/query-error');
var HEADER_HEIGHT = 38;
var SEGMENT_WIDTH = 300;
var INDENT_WIDTH = 25;
var MEASURE_WIDTH = 100;
var ROW_HEIGHT = 30;
var SPACE_LEFT = 10;
var SPACE_RIGHT = 10;
var ROW_PADDING_RIGHT = 50;
var BODY_PADDING_BOTTOM = 90;
var HIGHLIGHT_CONTROLS_TOP = -34;
function formatSegment(value) {
    if (plywood_1.TimeRange.isTimeRange(value)) {
        return value.start.toISOString();
    }
    return String(value);
}
function getFilterFromDatum(splits, flatDatum) {
    if (flatDatum['__nest'] === 0)
        return null;
    var segments = [];
    while (flatDatum['__nest'] > 0) {
        segments.unshift(flatDatum[constants_1.SEGMENT]);
        flatDatum = flatDatum['__parent'];
    }
    return new index_1.Filter(immutable_1.List(segments.map(function (segment, i) {
        return new index_1.FilterClause({
            expression: splits.get(i).expression,
            selection: plywood_1.r(plywood_1.TimeRange.isTimeRange(segment) ? segment : plywood_1.Set.fromJS([segment]))
        });
    })));
}
var Table = (function (_super) {
    __extends(Table, _super);
    function Table() {
        _super.call(this);
        this.state = {
            loading: false,
            dataset: null,
            error: null,
            flatData: null,
            scrollLeft: 0,
            scrollTop: 0,
            hoverMeasure: null,
            hoverRow: null
        };
    }
    Table.handleCircumstance = function (dataSource, splits, colors, current) {
        // Must have at least one dimension
        if (splits.length() === 0) {
            var someDimensions = dataSource.dimensions.toArray().filter(function (d) { return d.kind === 'string'; }).slice(0, 2);
            return index_1.Resolve.manual(4, 'This visualization requires at least one split', someDimensions.map(function (someDimension) {
                return {
                    description: "Add a split on " + someDimension.title,
                    adjustment: {
                        splits: index_1.Splits.fromSplitCombine(index_1.SplitCombine.fromExpression(someDimension.expression))
                    }
                };
            }));
        }
        // Auto adjustment
        var autoChanged = false;
        splits = splits.map(function (split, i) {
            var splitDimension = dataSource.getDimensionByExpression(split.expression);
            if (!split.sortAction) {
                split = split.changeSortAction(dataSource.getDefaultSortAction());
                autoChanged = true;
            }
            else if (split.sortAction.refName() === constants_1.TIME_SEGMENT) {
                split = split.changeSortAction(new plywood_1.SortAction({
                    expression: plywood_1.$(constants_1.SEGMENT),
                    direction: split.sortAction.direction
                }));
                autoChanged = true;
            }
            // ToDo: review this
            if (!split.limitAction && (autoChanged || splitDimension.kind !== 'time')) {
                split = split.changeLimit(i ? 5 : 50);
                autoChanged = true;
            }
            return split;
        });
        if (colors) {
            colors = null;
            autoChanged = true;
        }
        return autoChanged ? index_1.Resolve.automatic(6, { splits: splits }) : index_1.Resolve.ready(10);
    };
    Table.prototype.fetchData = function (essence) {
        var _this = this;
        var splits = essence.splits, dataSource = essence.dataSource;
        var measures = essence.getMeasures();
        var $main = plywood_1.$('main');
        var query = plywood_1.ply()
            .apply('main', $main.filter(essence.getEffectiveFilter(Table.id).toExpression()));
        measures.forEach(function (measure) {
            query = query.performAction(measure.toApplyAction());
        });
        function makeQuery(i) {
            var split = splits.get(i);
            var sortAction = split.sortAction, limitAction = split.limitAction;
            if (!sortAction)
                throw new Error('something went wrong in table query generation');
            var subQuery = $main.split(split.toSplitExpression(), constants_1.SEGMENT);
            measures.forEach(function (measure) {
                subQuery = subQuery.performAction(measure.toApplyAction());
            });
            var applyForSort = essence.getApplyForSort(sortAction);
            if (applyForSort) {
                subQuery = subQuery.performAction(applyForSort);
            }
            subQuery = subQuery.performAction(sortAction);
            if (limitAction) {
                subQuery = subQuery.performAction(limitAction);
            }
            if (i + 1 < splits.length()) {
                subQuery = subQuery.apply(constants_1.SPLIT, makeQuery(i + 1));
            }
            return subQuery;
        }
        query = query.apply(constants_1.SPLIT, makeQuery(0));
        this.setState({ loading: true });
        dataSource.executor(query)
            .then(function (dataset) {
            if (!_this.mounted)
                return;
            _this.setState({
                loading: false,
                dataset: dataset,
                error: null,
                flatData: dataset.flatten({
                    order: 'preorder',
                    nestingName: '__nest',
                    parentName: '__parent'
                })
            });
        }, function (error) {
            if (!_this.mounted)
                return;
            _this.setState({
                loading: false,
                dataset: null,
                error: error,
                flatData: null
            });
        });
    };
    Table.prototype.componentDidMount = function () {
        this.mounted = true;
        var essence = this.props.essence;
        this.fetchData(essence);
    };
    Table.prototype.componentWillReceiveProps = function (nextProps) {
        var essence = this.props.essence;
        var nextEssence = nextProps.essence;
        if (nextEssence.differentDataSource(essence) ||
            nextEssence.differentEffectiveFilter(essence, Table.id) ||
            nextEssence.differentSplits(essence) ||
            nextEssence.newSelectedMeasures(essence)) {
            this.fetchData(nextEssence);
        }
    };
    Table.prototype.componentWillUnmount = function () {
        this.mounted = false;
    };
    Table.prototype.onScroll = function (e) {
        var target = e.target;
        this.setState({
            scrollLeft: target.scrollLeft,
            scrollTop: target.scrollTop
        });
    };
    Table.prototype.calculateMousePosition = function (e) {
        var essence = this.props.essence;
        var _a = this.state, flatData = _a.flatData, scrollLeft = _a.scrollLeft, scrollTop = _a.scrollTop;
        var rect = ReactDOM.findDOMNode(this.refs['base']).getBoundingClientRect();
        var x = dom_1.getXFromEvent(e) - rect.left;
        var y = dom_1.getYFromEvent(e) - rect.top;
        if (x <= SPACE_LEFT)
            return { what: 'space-left' };
        x -= SPACE_LEFT;
        if (y <= HEADER_HEIGHT) {
            if (x <= SEGMENT_WIDTH)
                return { what: 'corner' };
            x = x - SEGMENT_WIDTH + scrollLeft;
            var measureIndex = Math.floor(x / MEASURE_WIDTH);
            var measure = essence.getMeasures().get(measureIndex);
            if (!measure)
                return { what: 'whitespace' };
            return { what: 'header', measure: measure };
        }
        y = y - HEADER_HEIGHT + scrollTop;
        var rowIndex = Math.floor(y / ROW_HEIGHT);
        var datum = flatData ? flatData[rowIndex] : null;
        if (!datum)
            return { what: 'whitespace' };
        return { what: 'row', row: datum };
    };
    Table.prototype.onMouseLeave = function () {
        var _a = this.state, hoverMeasure = _a.hoverMeasure, hoverRow = _a.hoverRow;
        if (hoverMeasure || hoverRow) {
            this.setState({
                hoverMeasure: null,
                hoverRow: null
            });
        }
    };
    Table.prototype.onMouseMove = function (e) {
        var _a = this.state, hoverMeasure = _a.hoverMeasure, hoverRow = _a.hoverRow;
        var pos = this.calculateMousePosition(e);
        if (hoverMeasure !== pos.measure || hoverRow !== pos.row) {
            this.setState({
                hoverMeasure: pos.measure,
                hoverRow: pos.row
            });
        }
    };
    Table.prototype.onClick = function (e) {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence;
        var pos = this.calculateMousePosition(e);
        // Hack
        if (pos.what === 'corner' && e.altKey && e.shiftKey) {
            var dataset = this.state.dataset;
            // Data "download" LOL
            console.log(dataset ? dataset.toTSV() : '[no dataset]');
            return;
        }
        if (pos.what === 'corner' || pos.what === 'header') {
            var sortExpression = plywood_1.$(pos.what === 'corner' ? constants_1.SEGMENT : pos.measure.name);
            var commonSort = essence.getCommonSort();
            var myDescending = (commonSort && commonSort.expression.equals(sortExpression) && commonSort.direction === plywood_1.SortAction.DESCENDING);
            clicker.changeSplits(essence.splits.changeSortAction(new plywood_1.SortAction({
                expression: sortExpression,
                direction: myDescending ? plywood_1.SortAction.ASCENDING : plywood_1.SortAction.DESCENDING
            })), index_1.VisStrategy.KeepAlways);
        }
        else if (pos.what === 'row') {
            var rowHighlight = getFilterFromDatum(essence.splits, pos.row);
            if (essence.highlightOn(Table.id)) {
                if (rowHighlight.equals(essence.highlight.delta)) {
                    clicker.dropHighlight();
                    return;
                }
            }
            clicker.changeHighlight(Table.id, rowHighlight);
        }
    };
    Table.prototype.render = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, stage = _a.stage;
        var _b = this.state, loading = _b.loading, error = _b.error, flatData = _b.flatData, scrollLeft = _b.scrollLeft, scrollTop = _b.scrollTop, hoverMeasure = _b.hoverMeasure, hoverRow = _b.hoverRow;
        var splits = essence.splits;
        var segmentTitle = splits.getTitle(essence.dataSource.dimensions);
        var commonSort = essence.getCommonSort();
        var commonSortName = commonSort ? commonSort.expression.name : null;
        var sortArrowIcon = commonSort ? React.createElement(svg_icon_1.SvgIcon, {
            svg: require('../../icons/sort-arrow.svg'),
            className: 'sort-arrow ' + commonSort.direction
        }) : null;
        var cornerSortArrow = null;
        if (commonSortName === constants_1.SEGMENT) {
            cornerSortArrow = sortArrowIcon;
        }
        var measuresArray = essence.getMeasures().toArray();
        var headerColumns = measuresArray.map(function (measure, i) {
            return <div className={'measure-name' + (measure === hoverMeasure ? ' hover' : '')} key={measure.name}>
        <div className="title-wrap">{measure.title}</div>
        {commonSortName === measure.name ? sortArrowIcon : null}
      </div>;
        });
        var segments = [];
        var rows = [];
        var highlighter = null;
        var highlighterStyle = null;
        if (flatData) {
            var formatters = measuresArray.map(function (measure) {
                var measureName = measure.name;
                var measureValues = flatData.map(function (d) { return d[measureName]; });
                return formatter_1.formatterFromData(measureValues, measure.format);
            });
            var highlightDelta = null;
            if (essence.highlightOn(Table.id)) {
                highlightDelta = essence.highlight.delta;
            }
            var skipNumber = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT));
            var lastElementToShow = Math.min(flatData.length, Math.ceil((scrollTop + stage.height) / ROW_HEIGHT));
            var rowY = skipNumber * ROW_HEIGHT;
            for (var i = skipNumber; i < lastElementToShow; i++) {
                var d = flatData[i];
                var nest = d['__nest'];
                var segmentValue = d[constants_1.SEGMENT];
                var segmentName = nest ? formatSegment(segmentValue) : 'Total';
                var left = Math.max(0, nest - 1) * INDENT_WIDTH;
                var segmentStyle = { left: left, width: SEGMENT_WIDTH - left, top: rowY };
                var hoverClass = d === hoverRow ? ' hover' : '';
                var selected = false;
                var selectedClass = '';
                if (highlightDelta) {
                    selected = highlightDelta && highlightDelta.equals(getFilterFromDatum(splits, d));
                    selectedClass = selected ? 'selected' : 'not-selected';
                }
                segments.push(<div className={'segment nest' + nest + ' ' + selectedClass + hoverClass} key={'_' + i} style={segmentStyle}>{segmentName}</div>);
                var row = measuresArray.map(function (measure, j) {
                    var measureValue = d[measure.name];
                    var measureValueStr = formatters[j](measureValue);
                    return <div className="measure" key={measure.name}>{measureValueStr}</div>;
                });
                var rowStyle = { top: rowY };
                rows.push(<div className={'row nest' + nest + ' ' + selectedClass + hoverClass} key={'_' + i} style={rowStyle}>{row}</div>);
                if (!highlighter && selected) {
                    highlighterStyle = {
                        top: rowY,
                        left: left
                    };
                    highlighter = <div className='highlighter' key='highlight' style={highlighterStyle}></div>;
                }
                rowY += ROW_HEIGHT;
            }
        }
        var rowWidth = MEASURE_WIDTH * measuresArray.length + ROW_PADDING_RIGHT;
        // Extended so that the horizontal lines extend fully
        var rowWidthExtended = rowWidth;
        if (stage) {
            rowWidthExtended = Math.max(rowWidthExtended, stage.width - (SPACE_LEFT + SEGMENT_WIDTH + SPACE_RIGHT));
        }
        var headerStyle = {
            width: rowWidthExtended,
            left: -scrollLeft
        };
        var segmentsStyle = {
            top: -scrollTop
        };
        var bodyHeight = flatData ? flatData.length * ROW_HEIGHT : 0;
        var bodyStyle = {
            left: -scrollLeft,
            top: -scrollTop,
            width: rowWidthExtended,
            height: bodyHeight
        };
        var highlightStyle = {
            top: -scrollTop
        };
        var horizontalScrollShadowStyle = { display: 'none' };
        if (scrollTop) {
            horizontalScrollShadowStyle = {
                width: SEGMENT_WIDTH + rowWidthExtended - scrollLeft
            };
        }
        var verticalScrollShadowStyle = { display: 'none' };
        if (scrollLeft) {
            verticalScrollShadowStyle = {};
        }
        var scrollerStyle = {
            width: SPACE_LEFT + SEGMENT_WIDTH + rowWidth + SPACE_RIGHT,
            height: HEADER_HEIGHT + bodyHeight + BODY_PADDING_BOTTOM
        };
        var highlightControls = null;
        if (highlighter) {
            highlightControls = React.createElement(highlight_controls_1.HighlightControls, {
                clicker: clicker,
                orientation: 'horizontal',
                style: {
                    top: HEADER_HEIGHT + highlighterStyle.top - scrollTop + HIGHLIGHT_CONTROLS_TOP
                }
            });
        }
        var loader = null;
        if (loading) {
            loader = <loader_1.Loader />;
        }
        var queryError = null;
        if (error) {
            queryError = <query_error_1.QueryError error={error}/>;
        }
        return <div className="table">
      <div className="corner">
        <div className="corner-wrap">{segmentTitle}</div>
        {cornerSortArrow}
      </div>
      <div className="header-cont">
        <div className="header" style={headerStyle}>{headerColumns}</div>
      </div>
      <div className="segments-cont">
        <div className="segments" style={segmentsStyle}>{segments}</div>
      </div>
      <div className="body-cont">
        <div className="body" style={bodyStyle}>{rows}</div>
      </div>
      <div className="highlight-cont">
        <div className="highlight" style={highlightStyle}>{highlighter}</div>
      </div>
      <div className="horizontal-scroll-shadow" style={horizontalScrollShadowStyle}></div>
      <div className="vertical-scroll-shadow" style={verticalScrollShadowStyle}></div>
      {queryError}
      {loader}
      <div className="scroller-cont" ref="base" onScroll={this.onScroll.bind(this)} onMouseLeave={this.onMouseLeave.bind(this)} onMouseMove={this.onMouseMove.bind(this)} onClick={this.onClick.bind(this)}>
        <div className="scroller" style={scrollerStyle}></div>
      </div>
      {highlightControls}
    </div>;
    };
    Table.id = 'table';
    Table.title = 'Table';
    return Table;
}(React.Component));
exports.Table = Table;
//# sourceMappingURL=table.js.map