"use strict";
var immutable_1 = require('immutable');
var totals_1 = require('./totals/totals');
var table_1 = require('./table/table');
var time_series_1 = require('./time-series/time-series');
var bar_chart_1 = require('./bar-chart/bar-chart');
var geo_1 = require('./geo/geo');
exports.visualizations = immutable_1.List([
    totals_1.Totals,
    table_1.Table,
    time_series_1.TimeSeries,
    bar_chart_1.BarChart,
    geo_1.Geo
]);
//# sourceMappingURL=index.js.map