"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./totals.css');
var React = require('react');
var plywood_1 = require('plywood');
var index_1 = require("../../../common/models/index");
var loader_1 = require('../../components/loader/loader');
var query_error_1 = require('../../components/query-error/query-error');
var PADDING_H = 100;
var TOTAL_WIDTH = 176;
var Totals = (function (_super) {
    __extends(Totals, _super);
    function Totals() {
        _super.call(this);
        this.state = {
            loading: false,
            dataset: null,
            error: null
        };
    }
    Totals.handleCircumstance = function (dataSource, splits, colors, current) {
        if (!splits.length())
            return index_1.Resolve.ready(10);
        return index_1.Resolve.automatic(3, { splits: index_1.Splits.EMPTY });
    };
    Totals.prototype.fetchData = function (essence) {
        var _this = this;
        var dataSource = essence.dataSource;
        var measures = essence.getMeasures();
        var $main = plywood_1.$('main');
        var query = plywood_1.ply()
            .apply('main', $main.filter(essence.getEffectiveFilter(Totals.id).toExpression()));
        measures.forEach(function (measure) {
            query = query.performAction(measure.toApplyAction());
        });
        this.setState({ loading: true });
        dataSource.executor(query)
            .then(function (dataset) {
            if (!_this.mounted)
                return;
            _this.setState({
                loading: false,
                dataset: dataset,
                error: null
            });
        }, function (error) {
            if (!_this.mounted)
                return;
            _this.setState({
                loading: false,
                dataset: null,
                error: error
            });
        });
    };
    Totals.prototype.componentDidMount = function () {
        this.mounted = true;
        var essence = this.props.essence;
        this.fetchData(essence);
    };
    Totals.prototype.componentWillReceiveProps = function (nextProps) {
        var essence = this.props.essence;
        var nextEssence = nextProps.essence;
        if (nextEssence.differentDataSource(essence) ||
            nextEssence.differentEffectiveFilter(essence, Totals.id) ||
            nextEssence.newSelectedMeasures(essence)) {
            this.fetchData(nextEssence);
        }
    };
    Totals.prototype.componentWillUnmount = function () {
        this.mounted = false;
    };
    Totals.prototype.render = function () {
        var _a = this.props, essence = _a.essence, stage = _a.stage;
        var _b = this.state, loading = _b.loading, dataset = _b.dataset, error = _b.error;
        var myDatum = dataset ? dataset.data[0] : null;
        var measures = essence.getMeasures();
        var single = measures.size === 1;
        var totals = measures.map(function (measure) {
            var measureName = measure.name;
            var measureValueStr = '-';
            if (myDatum) {
                measureValueStr = measure.formatFn(myDatum[measureName]);
            }
            return <div className={'total' + (single ? ' single' : '')} key={measure.name}>
        <div className="measure-name">{measure.title}</div>
        <div className="measure-value">{measureValueStr}</div>
      </div>;
        });
        var loader = null;
        if (loading) {
            loader = <loader_1.Loader />;
        }
        var queryError = null;
        if (error) {
            queryError = <query_error_1.QueryError error={error}/>;
        }
        var totalContainerStyle = null;
        if (!single) {
            var numColumns = Math.min(totals.size, Math.max(1, Math.floor((stage.width - 2 * PADDING_H) / TOTAL_WIDTH)));
            var containerWidth = numColumns * TOTAL_WIDTH;
            totalContainerStyle = {
                left: '50%',
                width: containerWidth,
                marginLeft: -containerWidth / 2
            };
        }
        return <div className="totals">
      <div className="total-container" style={totalContainerStyle}>{totals}</div>
      {queryError}
      {loader}
    </div>;
    };
    Totals.id = 'totals';
    Totals.title = 'Totals';
    return Totals;
}(React.Component));
exports.Totals = Totals;
//# sourceMappingURL=totals.js.map