"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./link-header-bar.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var LinkHeaderBar = (function (_super) {
    __extends(LinkHeaderBar, _super);
    function LinkHeaderBar() {
        _super.call(this);
        //this.state = {};
    }
    LinkHeaderBar.prototype.render = function () {
        var _a = this.props, title = _a.title, user = _a.user, onNavClick = _a.onNavClick, onExploreClick = _a.onExploreClick;
        var userButton = null;
        if (user) {
            userButton = <div className="icon-button">
        <svg_icon_1.SvgIcon svg={require('../../icons/full-user.svg')}/>
      </div>;
        }
        return <header className="link-header-bar">
      <div className="left-bar" onClick={onNavClick}>
        <div className="menu-icon">
          <svg_icon_1.SvgIcon svg={require('../../icons/menu.svg')}/>
        </div>
        <div className="title">{title}</div>
      </div>
      <div className="right-bar">
        <div className="text-button" onClick={onExploreClick}>Explore</div>
        <a className="icon-button help" href="https://groups.google.com/forum/#!forum/imply-user-group" target="_blank">
          <svg_icon_1.SvgIcon className="help-icon" svg={require('../../icons/help.svg')}/>
        </a>
        {userButton}
      </div>
    </header>;
    };
    return LinkHeaderBar;
}(React.Component));
exports.LinkHeaderBar = LinkHeaderBar;
//# sourceMappingURL=link-header-bar.js.map