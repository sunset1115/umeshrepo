"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./manual-fallback.css');
var React = require('react');
// import { ... } from '../../config/constants';
var index_1 = require('../../../common/models/index');
var ManualFallback = (function (_super) {
    __extends(ManualFallback, _super);
    function ManualFallback() {
        _super.call(this);
        // this.state = {};
    }
    ManualFallback.prototype.onResolutionClick = function (resolution) {
        var clicker = this.props.clicker;
        clicker.changeSplits(resolution.adjustment.splits, index_1.VisStrategy.KeepAlways);
    };
    ManualFallback.prototype.render = function () {
        var _this = this;
        var essence = this.props.essence;
        var visResolve = essence.visResolve;
        if (!visResolve.isManual())
            return null;
        var resolutionItems = visResolve.resolutions.map(function (resolution, i) {
            return <li key={i} onClick={_this.onResolutionClick.bind(_this, resolution)}>{resolution.description}</li>;
        });
        return <div className="manual-fallback">
      <div className="message">{visResolve.message}</div>
      <ul>{resolutionItems}</ul>
    </div>;
    };
    return ManualFallback;
}(React.Component));
exports.ManualFallback = ManualFallback;
//# sourceMappingURL=manual-fallback.js.map