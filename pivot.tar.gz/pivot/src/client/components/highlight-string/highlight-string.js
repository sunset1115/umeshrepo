"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./highlight-string.css');
var React = require('react');
var HighlightString = (function (_super) {
    __extends(HighlightString, _super);
    function HighlightString() {
        _super.call(this);
        // this.state = {};
    }
    HighlightString.prototype.highlightInString = function () {
        var _a = this.props, text = _a.text, highlightText = _a.highlightText;
        if (!highlightText)
            return text;
        var strLower = text.toLowerCase();
        var startIndex = strLower.indexOf(highlightText.toLowerCase());
        if (startIndex === -1)
            return text;
        var endIndex = startIndex + highlightText.length;
        return [
            <span className="pre" key="pre">{text.substring(0, startIndex)}</span>,
            <span className="bold" key="bold">{text.substring(startIndex, endIndex)}</span>,
            <span className="post" key="post">{text.substring(endIndex)}</span>
        ];
    };
    HighlightString.prototype.render = function () {
        var className = this.props.className;
        return <div className={'highlight-string ' + (className || '')}>{this.highlightInString()}</div>;
    };
    return HighlightString;
}(React.Component));
exports.HighlightString = HighlightString;
//# sourceMappingURL=highlight-string.js.map