"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./time-axis.css');
var React = require('react');
// import { SomeComp } from '../some-comp/some-comp';
var TICK_HEIGHT = 5;
var TEXT_OFFSET = 12;
var TimeAxis = (function (_super) {
    __extends(TimeAxis, _super);
    function TimeAxis() {
        _super.call(this);
        // this.state = {};
    }
    TimeAxis.prototype.render = function () {
        var _a = this.props, stage = _a.stage, xTicks = _a.xTicks, scaleX = _a.scaleX;
        //var format = d3.time.format('%b %-d');
        var format = scaleX.tickFormat();
        var lines = xTicks.map(function (tick, i) {
            var x = scaleX(tick);
            return <line key={String(tick)} x1={x} y1={0} x2={x} y2={TICK_HEIGHT}/>;
        });
        var labelY = TICK_HEIGHT + TEXT_OFFSET;
        var labels = xTicks.map(function (tick, i) {
            var x = scaleX(tick);
            return <text key={String(tick)} x={x} y={labelY}>{format(tick)}</text>;
        });
        return <g className="time-axis" transform={stage.getTransform()}>
      {lines}
      {labels}
    </g>;
    };
    return TimeAxis;
}(React.Component));
exports.TimeAxis = TimeAxis;
//# sourceMappingURL=time-axis.js.map