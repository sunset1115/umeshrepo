"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./highlighter.css');
var React = require('react');
var ReactDOM = require('react-dom');
var plywood_1 = require('plywood');
var index_1 = require('../../../common/models/index');
var dom_1 = require('../../utils/dom/dom');
var highlight_controls_1 = require('../highlight-controls/highlight-controls');
var Highlighter = (function (_super) {
    __extends(Highlighter, _super);
    function Highlighter() {
        _super.call(this);
        this.state = {
            pseudoHighlight: null,
            dragStartPx: null
        };
        this.globalMouseMoveListener = this.globalMouseMoveListener.bind(this);
        this.globalMouseUpListener = this.globalMouseUpListener.bind(this);
        this.globalKeyDownListener = this.globalKeyDownListener.bind(this);
    }
    Highlighter.prototype.componentDidMount = function () {
        var dragStart = this.props.dragStart;
        window.addEventListener('keydown', this.globalKeyDownListener);
        window.addEventListener('mousemove', this.globalMouseMoveListener);
        window.addEventListener('mouseup', this.globalMouseUpListener);
        this.setState({ dragStartPx: dragStart });
    };
    Highlighter.prototype.componentWillUnmount = function () {
        window.removeEventListener('keydown', this.globalKeyDownListener);
        window.removeEventListener('mousemove', this.globalMouseMoveListener);
        window.removeEventListener('mouseup', this.globalMouseUpListener);
    };
    Highlighter.prototype.getPseudoHighlight = function (eventX) {
        var scaleX = this.props.scaleX;
        var dragStartPx = this.state.dragStartPx;
        var myDOM = ReactDOM.findDOMNode(this);
        var d1 = scaleX.invert(dragStartPx);
        var d2 = scaleX.invert(eventX - myDOM.getBoundingClientRect().left);
        if (d1 < d2) {
            return plywood_1.TimeRange.fromJS({ start: d1, end: d2 });
        }
        else {
            return plywood_1.TimeRange.fromJS({ start: d2, end: d1 });
        }
    };
    Highlighter.prototype.onMouseDown = function (e) {
        var dragStartPx = this.state.dragStartPx;
        if (dragStartPx !== null)
            return;
        var myDOM = ReactDOM.findDOMNode(this);
        dragStartPx = dom_1.getXFromEvent(e) - (myDOM.getBoundingClientRect().left);
        this.setState({ dragStartPx: dragStartPx });
    };
    Highlighter.prototype.globalMouseMoveListener = function (e) {
        var dragStartPx = this.state.dragStartPx;
        if (dragStartPx === null)
            return;
        this.setState({
            pseudoHighlight: this.getPseudoHighlight(dom_1.getXFromEvent(e))
        });
    };
    Highlighter.prototype.globalMouseUpListener = function (e) {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, highlightId = _a.highlightId, duration = _a.duration, timezone = _a.timezone, onClose = _a.onClose;
        var _b = this.state, dragStartPx = _b.dragStartPx, pseudoHighlight = _b.pseudoHighlight;
        if (dragStartPx === null)
            return;
        if (!pseudoHighlight) {
            clicker.dropHighlight();
            onClose();
            return;
        }
        pseudoHighlight = this.getPseudoHighlight(dom_1.getXFromEvent(e));
        this.setState({
            dragStartPx: null,
            pseudoHighlight: null
        });
        var timeRange = plywood_1.TimeRange.fromJS({
            start: duration.floor(pseudoHighlight.start, timezone),
            end: duration.move(duration.floor(pseudoHighlight.end, timezone), timezone, 1)
        });
        var timeDimension = essence.getTimeDimension();
        clicker.changeHighlight(highlightId, index_1.Filter.fromClause(new index_1.FilterClause({
            expression: timeDimension.expression,
            selection: plywood_1.r(timeRange)
        })));
    };
    Highlighter.prototype.globalKeyDownListener = function (e) {
        if (!dom_1.escapeKey(e))
            return;
        var onClose = this.props.onClose;
        onClose();
    };
    Highlighter.prototype.render = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, highlightId = _a.highlightId, scaleX = _a.scaleX, onClose = _a.onClose;
        var _b = this.state, pseudoHighlight = _b.pseudoHighlight, dragStartPx = _b.dragStartPx;
        var shownTimeRange = pseudoHighlight;
        if (!shownTimeRange) {
            if (essence.highlightOn(highlightId)) {
                shownTimeRange = essence.getSingleHighlightSet().elements[0];
            }
        }
        if (!shownTimeRange) {
            return <div className='highlighter'></div>;
        }
        var highlightControls = null;
        if (dragStartPx === null) {
            highlightControls = <highlight_controls_1.HighlightControls clicker={clicker} orientation="vertical" onClose={onClose}/>;
        }
        var startPos = scaleX(shownTimeRange.start);
        var endPos = scaleX(shownTimeRange.end);
        var whiteoutLeftStyle = {
            width: Math.max(startPos, 0)
        };
        var frameStyle = {
            left: startPos,
            width: Math.max(endPos - startPos, 0)
        };
        var whiteoutRightStyle = {
            left: endPos
        };
        return <div className={'highlighter ' + (dragStartPx !== null ? 'dragging' : 'confirm')} onMouseDown={this.onMouseDown.bind(this)}>
      <div className="whiteout left" style={whiteoutLeftStyle}></div>
      <div className="frame" style={frameStyle}>{highlightControls}</div>
      <div className="whiteout right" style={whiteoutRightStyle}></div>
    </div>;
    };
    return Highlighter;
}(React.Component));
exports.Highlighter = Highlighter;
//# sourceMappingURL=highlighter.js.map