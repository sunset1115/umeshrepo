"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./tile-header.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var TileHeader = (function (_super) {
    __extends(TileHeader, _super);
    function TileHeader() {
        _super.call(this);
        // this.state = {};
    }
    TileHeader.prototype.render = function () {
        var _a = this.props, title = _a.title, onDragStart = _a.onDragStart, onSearch = _a.onSearch, onClose = _a.onClose;
        var icons = [];
        if (onSearch) {
            icons.push(<div className="icon search" key="search" onClick={onSearch}>
        <svg_icon_1.SvgIcon svg={require('../../icons/full-search.svg')}/>
      </div>);
        }
        if (onClose) {
            icons.push(<div className="icon close" key="close" onClick={onClose}>
        <svg_icon_1.SvgIcon svg={require('../../icons/full-remove.svg')}/>
      </div>);
        }
        return <div className="tile-header" draggable={onDragStart ? true : null} onDragStart={onDragStart}>
      <div className="title">{title}</div>
      <div className="icons">{icons}</div>
    </div>;
    };
    return TileHeader;
}(React.Component));
exports.TileHeader = TileHeader;
//# sourceMappingURL=tile-header.js.map