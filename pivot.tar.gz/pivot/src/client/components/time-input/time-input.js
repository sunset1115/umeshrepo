"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./time-input.css');
var React = require('react');
// import { SvgIcon } from '../svg-icon/svg-icon';
var chronoshift_1 = require('chronoshift');
var TimeInput = (function (_super) {
    __extends(TimeInput, _super);
    function TimeInput() {
        _super.call(this);
        this.state = {
            dateString: '',
            timeString: ''
        };
    }
    // 2015-09-23T17:42:57.636Z
    // 2015-09-23 17:42
    TimeInput.prototype.componentDidMount = function () {
        var _a = this.props, time = _a.time, timezone = _a.timezone;
        this.updateStateFromTime(time, timezone);
    };
    TimeInput.prototype.componentWillReceiveProps = function (nextProps) {
        var time = nextProps.time, timezone = nextProps.timezone;
        this.updateStateFromTime(time, timezone);
    };
    TimeInput.prototype.updateStateFromTime = function (time, timezone) {
        if (!time)
            return;
        if (isNaN(time.valueOf())) {
            this.setState({
                dateString: '',
                timeString: ''
            });
            return;
        }
        var adjTime = chronoshift_1.WallTime.UTCToWallTime(time, timezone.toString());
        var timeISO = adjTime.toISOString().replace(/:\d\d(\.\d\d\d)?Z?$/, '').split('T');
        this.setState({
            dateString: timeISO[0],
            timeString: timeISO[1]
        });
    };
    TimeInput.prototype.dateChange = function (e) {
        var timeString = this.state.timeString;
        var dateString = e.target.value.replace(/[^\d-]/g, '').substr(0, 10);
        this.setState({
            dateString: dateString
        });
        if (dateString.length === 10) {
            this.changeDate(dateString + 'T' + timeString + 'Z');
        }
        else {
            this.changeDate('blah');
        }
    };
    TimeInput.prototype.timeChange = function (e) {
        var dateString = this.state.dateString;
        var timeString = e.target.value.replace(/[^\d:]/g, '').substr(0, 8);
        this.setState({
            timeString: timeString
        });
        this.changeDate(dateString + 'T' + timeString + 'Z');
    };
    TimeInput.prototype.changeDate = function (possibleDateString) {
        var _a = this.props, timezone = _a.timezone, onChange = _a.onChange;
        var possibleDate = new Date(possibleDateString);
        if (isNaN(possibleDate.valueOf())) {
            onChange(null);
        }
        else {
            // Convert from WallTime to UTC
            var possibleDate = chronoshift_1.WallTime.WallTimeToUTC(timezone.toString(), possibleDate.getUTCFullYear(), possibleDate.getUTCMonth(), possibleDate.getUTCDate(), possibleDate.getUTCHours(), possibleDate.getUTCMinutes(), possibleDate.getUTCSeconds(), possibleDate.getUTCMilliseconds());
            onChange(possibleDate);
        }
    };
    TimeInput.prototype.render = function () {
        var _a = this.state, dateString = _a.dateString, timeString = _a.timeString;
        return <div className="time-input">
      <input className="date" value={dateString} onChange={this.dateChange.bind(this)}/>
      <input className="time" value={timeString} onChange={this.timeChange.bind(this)}/>
    </div>;
    };
    return TimeInput;
}(React.Component));
exports.TimeInput = TimeInput;
//# sourceMappingURL=time-input.js.map