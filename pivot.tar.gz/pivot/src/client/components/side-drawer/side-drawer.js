"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./side-drawer.css');
var React = require('react');
var ReactDOM = require('react-dom');
var constants_1 = require('../../config/constants');
var dom_1 = require('../../utils/dom/dom');
var nav_logo_1 = require('../nav-logo/nav-logo');
var nav_list_1 = require('../nav-list/nav-list');
var SideDrawer = (function (_super) {
    __extends(SideDrawer, _super);
    function SideDrawer() {
        _super.call(this);
        // this.state = {};
        this.globalMouseDownListener = this.globalMouseDownListener.bind(this);
        this.globalKeyDownListener = this.globalKeyDownListener.bind(this);
    }
    SideDrawer.prototype.componentDidMount = function () {
        window.addEventListener('mousedown', this.globalMouseDownListener);
        window.addEventListener('keydown', this.globalKeyDownListener);
    };
    SideDrawer.prototype.componentWillUnmount = function () {
        window.removeEventListener('mousedown', this.globalMouseDownListener);
        window.removeEventListener('keydown', this.globalKeyDownListener);
    };
    SideDrawer.prototype.globalMouseDownListener = function (e) {
        var myElement = ReactDOM.findDOMNode(this);
        var target = e.target;
        if (dom_1.isInside(target, myElement))
            return;
        this.props.onClose();
    };
    SideDrawer.prototype.globalKeyDownListener = function (e) {
        if (!dom_1.escapeKey(e))
            return;
        this.props.onClose();
    };
    SideDrawer.prototype.selectDataSource = function (dataSource) {
        var _a = this.props, changeDataSource = _a.changeDataSource, onClose = _a.onClose;
        changeDataSource(dataSource);
        onClose();
    };
    SideDrawer.prototype.selectLink = function (selected) {
        if (selected.target) {
            window.open(selected.target);
            return false;
        }
        else {
            return; // state change for application to handle
        }
    };
    ;
    SideDrawer.prototype.render = function () {
        var _a = this.props, onClose = _a.onClose, selectedDataSource = _a.selectedDataSource, dataSources = _a.dataSources;
        return <div className="side-drawer">
      <nav_logo_1.NavLogo onClick={onClose}/>
      <nav_list_1.NavList title="Data Cubes" className="items" selected={selectedDataSource ? selectedDataSource.name : null} navItems={dataSources} onSelect={this.selectDataSource.bind(this)} icon="'../../full-cube.svg'"/>
      <nav_list_1.NavList className="items" navItems={constants_1.ADDITIONAL_LINKS} onSelect={this.selectLink.bind(this)}/>
    </div>;
    };
    return SideDrawer;
}(React.Component));
exports.SideDrawer = SideDrawer;
//# sourceMappingURL=side-drawer.js.map