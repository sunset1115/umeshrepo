"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./query-error.css');
var React = require('react');
var constants_1 = require('../../config/constants');
var QueryError = (function (_super) {
    __extends(QueryError, _super);
    function QueryError() {
        _super.call(this);
        // this.state = {};
    }
    QueryError.prototype.render = function () {
        var error = this.props.error;
        return <div className="query-error">
      <div className="whiteout"></div>
      <div className="container">
        <div className="error">{constants_1.STRINGS.queryError}</div>
        <div className="message">{error.message}</div>
      </div>
    </div>;
    };
    return QueryError;
}(React.Component));
exports.QueryError = QueryError;
//# sourceMappingURL=query-error.js.map