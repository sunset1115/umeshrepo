"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./preview-menu.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var constants_1 = require('../../config/constants');
var index_1 = require('../../../common/models/index');
var bubble_menu_1 = require('../bubble-menu/bubble-menu');
//import { MenuHeader } from '../menu-header/menu-header';
//import { MenuTable } from '../menu-table/menu-table';
//import { MenuTimeSeries } from '../menu-time-series/menu-time-series';
var ACTION_SIZE = 60;
var PreviewMenu = (function (_super) {
    __extends(PreviewMenu, _super);
    function PreviewMenu() {
        _super.call(this);
        //this.state = {
        //};
    }
    PreviewMenu.prototype.onFilter = function () {
        var _a = this.props, dimension = _a.dimension, triggerFilterMenu = _a.triggerFilterMenu, onClose = _a.onClose;
        triggerFilterMenu(dimension);
        onClose();
    };
    PreviewMenu.prototype.onSplit = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, dimension = _a.dimension, triggerSplitMenu = _a.triggerSplitMenu, onClose = _a.onClose;
        if (essence.splits.hasSplitOn(dimension) && essence.splits.length() === 1) {
            triggerSplitMenu(dimension);
        }
        else {
            clicker.changeSplit(index_1.SplitCombine.fromExpression(dimension.expression), index_1.VisStrategy.UnfairGame);
        }
        onClose();
    };
    PreviewMenu.prototype.onSubsplit = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, dimension = _a.dimension, triggerSplitMenu = _a.triggerSplitMenu, onClose = _a.onClose;
        if (essence.splits.hasSplitOn(dimension)) {
            triggerSplitMenu(dimension);
        }
        else {
            clicker.addSplit(index_1.SplitCombine.fromExpression(dimension.expression), index_1.VisStrategy.UnfairGame);
        }
        onClose();
    };
    PreviewMenu.prototype.onPin = function () {
        var _a = this.props, clicker = _a.clicker, dimension = _a.dimension, onClose = _a.onClose;
        clicker.pin(dimension);
        onClose();
    };
    PreviewMenu.prototype.render = function () {
        var _a = this.props, direction = _a.direction, containerStage = _a.containerStage, openOn = _a.openOn, dimension = _a.dimension, onClose = _a.onClose;
        if (!dimension)
            return null;
        var menuSize = index_1.Stage.fromSize(ACTION_SIZE * 2, ACTION_SIZE * 2);
        return <bubble_menu_1.BubbleMenu className="preview-menu" direction={direction} containerStage={containerStage} stage={menuSize} fixedSize={true} openOn={openOn} onClose={onClose}>
      <div className="filter action" onClick={this.onFilter.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/preview-filter.svg')}/>
        <div className="action-label">{constants_1.STRINGS.filter}</div>
      </div>
      <div className="pin action" onClick={this.onPin.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/preview-pin.svg')}/>
        <div className="action-label">{constants_1.STRINGS.pin}</div>
      </div>
      <div className="split action" onClick={this.onSplit.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/preview-split.svg')}/>
        <div className="action-label">{constants_1.STRINGS.split}</div>
      </div>
      <div className="subsplit action" onClick={this.onSubsplit.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/preview-subsplit.svg')}/>
        <div className="action-label">{constants_1.STRINGS.subsplit}</div>
      </div>
    </bubble_menu_1.BubbleMenu>;
    };
    return PreviewMenu;
}(React.Component));
exports.PreviewMenu = PreviewMenu;
//# sourceMappingURL=preview-menu.js.map