"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./hover-bubble.css');
var React = require('react');
var constants_1 = require('../../config/constants');
var date_1 = require('../../utils/date/date');
var body_portal_1 = require('../body-portal/body-portal');
var HoverBubble = (function (_super) {
    __extends(HoverBubble, _super);
    function HoverBubble() {
        _super.call(this);
        // this.state = {};
    }
    HoverBubble.prototype.render = function () {
        var _a = this.props, essence = _a.essence, datum = _a.datum, measure = _a.measure, getY = _a.getY, left = _a.left, top = _a.top;
        return <body_portal_1.BodyPortal left={left} top={top} disablePointerEvents={true}>
      <div className="hover-bubble">
        <div className="hover-bubble-inner">
          <div className="text">
            <span className="bucket">{date_1.formatTimeRange(datum[constants_1.TIME_SEGMENT], essence.timezone, date_1.DisplayYear.NEVER)}</span>
            <span className="measure-value">{measure.formatFn(getY(datum))}</span>
          </div>
          <div className="shpitz"></div>
        </div>
      </div>
    </body_portal_1.BodyPortal>;
    };
    return HoverBubble;
}(React.Component));
exports.HoverBubble = HoverBubble;
//# sourceMappingURL=hover-bubble.js.map