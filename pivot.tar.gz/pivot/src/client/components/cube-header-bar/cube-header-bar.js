"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./cube-header-bar.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var modal_1 = require('../modal/modal');
var CubeHeaderBar = (function (_super) {
    __extends(CubeHeaderBar, _super);
    function CubeHeaderBar() {
        _super.call(this);
        this.state = {
            showTestMenu: false
        };
    }
    CubeHeaderBar.prototype.onPanicClick = function (e) {
        var _a = this.props, dataSource = _a.dataSource, getUrlPrefix = _a.getUrlPrefix;
        if (e.altKey) {
            console.log('DataSource:', dataSource.toJS());
            return;
        }
        if (e.shiftKey) {
            this.setState({
                showTestMenu: true
            });
            return;
        }
        window.location.assign(getUrlPrefix(true));
    };
    CubeHeaderBar.prototype.onModalClose = function () {
        this.setState({
            showTestMenu: false
        });
    };
    CubeHeaderBar.prototype.renderTestModal = function () {
        if (!this.state.showTestMenu)
            return null;
        return <modal_1.Modal className="test-modal" title="Test Modal" onClose={this.onModalClose.bind(this)}>
      <div>Hello 1</div>
      <div>Hello 2</div>
      <div>Hello 3</div>
    </modal_1.Modal>;
    };
    CubeHeaderBar.prototype.render = function () {
        var _a = this.props, user = _a.user, onNavClick = _a.onNavClick, dataSource = _a.dataSource;
        var userButton = null;
        if (user) {
            userButton = <div className="icon-button">
        <svg_icon_1.SvgIcon svg={require('../../icons/full-user.svg')}/>
      </div>;
        }
        return <header className="cube-header-bar">
      <div className="left-bar" onClick={onNavClick}>
        <div className="menu-icon">
          <svg_icon_1.SvgIcon svg={require('../../icons/menu.svg')}/>
        </div>
        <div className="title">{dataSource.title}</div>
      </div>
      <div className="right-bar">
        <div className="icon-button panic" onClick={this.onPanicClick.bind(this)}>
          <svg_icon_1.SvgIcon className="panic-icon" svg={require('../../icons/panic.svg')}/>
        </div>
        <a className="icon-button help" href="https://groups.google.com/forum/#!forum/imply-user-group" target="_blank">
          <svg_icon_1.SvgIcon className="help-icon" svg={require('../../icons/help.svg')}/>
        </a>
        <a className="icon-button github" href="https://github.com/implydata/pivot" target="_blank">
          <svg_icon_1.SvgIcon className="github-icon" svg={require('../../icons/github.svg')}/>
        </a>
        {userButton}
      </div>
      {this.renderTestModal()}
    </header>;
    };
    return CubeHeaderBar;
}(React.Component));
exports.CubeHeaderBar = CubeHeaderBar;
//# sourceMappingURL=cube-header-bar.js.map