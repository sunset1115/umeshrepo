"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./modal.css');
var React = require('react');
var ReactDOM = require('react-dom');
var dom_1 = require('../../utils/dom/dom');
var body_portal_1 = require('../body-portal/body-portal');
var TOP_RATIO = 0.618 / 1.618;
var Modal = (function (_super) {
    __extends(Modal, _super);
    function Modal() {
        _super.call(this);
        this.state = {
            id: null,
            windowTop: 0
        };
        this.globalResizeListener = this.globalResizeListener.bind(this);
        this.globalMouseDownListener = this.globalMouseDownListener.bind(this);
        this.globalKeyDownListener = this.globalKeyDownListener.bind(this);
    }
    Modal.prototype.componentWillMount = function () {
        var id = this.props.id;
        this.setState({
            id: id || dom_1.uniqueId('modal-')
        });
    };
    Modal.prototype.componentDidMount = function () {
        window.addEventListener('mousedown', this.globalMouseDownListener);
        window.addEventListener('keydown', this.globalKeyDownListener);
        window.addEventListener('resize', this.globalResizeListener);
        this.globalResizeListener();
    };
    Modal.prototype.componentWillUnmount = function () {
        window.removeEventListener('mousedown', this.globalMouseDownListener);
        window.removeEventListener('keydown', this.globalKeyDownListener);
        window.removeEventListener('resize', this.globalResizeListener);
    };
    Modal.prototype.globalMouseDownListener = function (e) {
        var _a = this.props, onClose = _a.onClose, mandatory = _a.mandatory;
        if (mandatory)
            return;
        var id = this.state.id;
        // can not use ReactDOM.findDOMNode(this) because portal?
        var myElement = document.getElementById(id);
        if (!myElement)
            return;
        var target = e.target;
        if (dom_1.isInside(target, myElement))
            return;
        onClose();
    };
    Modal.prototype.globalKeyDownListener = function (e) {
        if (!dom_1.escapeKey(e))
            return;
        var _a = this.props, onClose = _a.onClose, mandatory = _a.mandatory;
        if (mandatory)
            return;
        onClose();
    };
    Modal.prototype.globalResizeListener = function () {
        var modalRect = ReactDOM.findDOMNode(this.refs['modal']).getBoundingClientRect();
        var windowRect = ReactDOM.findDOMNode(this.refs['window']).getBoundingClientRect();
        var windowTop = (modalRect.height - windowRect.height) * TOP_RATIO;
        this.setState({ windowTop: windowTop });
    };
    Modal.prototype.render = function () {
        var _a = this.props, className = _a.className, title = _a.title, children = _a.children;
        var _b = this.state, id = _b.id, windowTop = _b.windowTop;
        var titleElement = null;
        if (typeof title === 'string') {
            titleElement = <div className="modal-title">
        {title}
      </div>;
        }
        var myClass = 'modal';
        if (className)
            myClass += ' ' + className;
        return <body_portal_1.BodyPortal fullSize={true}>
      <div className={myClass} ref="modal">
        <div className="backdrop"></div>
        <div className="modal-window" id={id} ref="window" style={{ top: windowTop }}>
          {titleElement}
          {children}
        </div>
      </div>
    </body_portal_1.BodyPortal>;
    };
    return Modal;
}(React.Component));
exports.Modal = Modal;
//# sourceMappingURL=modal.js.map