"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./filter-menu.css');
var React = require('react');
var index_1 = require('../../../common/models/index');
var bubble_menu_1 = require('../bubble-menu/bubble-menu');
var string_filter_menu_1 = require('../string-filter-menu/string-filter-menu');
var time_filter_menu_1 = require('../time-filter-menu/time-filter-menu');
var FilterMenu = (function (_super) {
    __extends(FilterMenu, _super);
    function FilterMenu() {
        _super.call(this);
        // this.state = {};
    }
    FilterMenu.prototype.render = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, insertPosition = _a.insertPosition, replacePosition = _a.replacePosition, direction = _a.direction, containerStage = _a.containerStage, openOn = _a.openOn, dimension = _a.dimension, onClose = _a.onClose, inside = _a.inside;
        if (!dimension)
            return null;
        var menuSize = null;
        var menuCont = null;
        if (dimension.kind === 'time') {
            menuSize = index_1.Stage.fromSize(250, 274);
            menuCont = <time_filter_menu_1.TimeFilterMenu clicker={clicker} dimension={dimension} essence={essence} onClose={onClose}/>;
        }
        else {
            menuSize = index_1.Stage.fromSize(250, 410);
            menuCont = <string_filter_menu_1.StringFilterMenu clicker={clicker} dimension={dimension} essence={essence} insertPosition={insertPosition} replacePosition={replacePosition} onClose={onClose}/>;
        }
        return <bubble_menu_1.BubbleMenu className="filter-menu" direction={direction} containerStage={containerStage} stage={menuSize} openOn={openOn} onClose={onClose} inside={inside}>
      {menuCont}
    </bubble_menu_1.BubbleMenu>;
    };
    return FilterMenu;
}(React.Component));
exports.FilterMenu = FilterMenu;
//# sourceMappingURL=filter-menu.js.map