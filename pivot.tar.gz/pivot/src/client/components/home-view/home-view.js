"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./home-view.css');
var React = require('react');
var constants_1 = require('../../config/constants');
var home_header_bar_1 = require('../home-header-bar/home-header-bar');
var nav_logo_1 = require('../nav-logo/nav-logo');
var nav_list_1 = require('../nav-list/nav-list');
var HomeView = (function (_super) {
    __extends(HomeView, _super);
    function HomeView() {
        _super.apply(this, arguments);
    }
    HomeView.prototype.selectLink = function (selected) {
        if (selected.target) {
            window.open(selected.target);
            return false;
        }
        else {
            return; // state change for application to handle
        }
    };
    ;
    HomeView.prototype.selectDataCube = function (dataCube) {
        this.props.selectDataCube(dataCube);
    };
    HomeView.prototype.render = function () {
        var _a = this.props, user = _a.user, onNavClick = _a.onNavClick;
        return <div className="home-view">
      <home_header_bar_1.HomeHeaderBar user={user} onNavClick={onNavClick}/>
      <div className="container">
        <div className="home">
          <nav_logo_1.NavLogo />
          <nav_list_1.NavList title="Data Cubes" className="items" navItems={this.props.dataCubes} onSelect={this.selectDataCube.bind(this)} icon="'../../full-cube.svg'"/>
          <nav_list_1.NavList className="items" navItems={constants_1.ADDITIONAL_LINKS} onSelect={this.selectLink.bind(this)}/>
        </div>
      </div>
    </div>;
    };
    return HomeView;
}(React.Component));
exports.HomeView = HomeView;
//# sourceMappingURL=home-view.js.map