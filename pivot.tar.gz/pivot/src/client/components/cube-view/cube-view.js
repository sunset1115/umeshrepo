"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./cube-view.css');
var React = require('react');
var ReactDOM = require('react-dom');
var drag_manager_1 = require('../../utils/drag-manager/drag-manager');
var index_1 = require('../../../common/models/index');
// import { ... } from '../../config/constants';
var cube_header_bar_1 = require('../cube-header-bar/cube-header-bar');
var dimension_measure_panel_1 = require('../dimension-measure-panel/dimension-measure-panel');
var filter_tile_1 = require('../filter-tile/filter-tile');
var split_tile_1 = require('../split-tile/split-tile');
var vis_selector_1 = require('../vis-selector/vis-selector');
var manual_fallback_1 = require('../manual-fallback/manual-fallback');
var drop_indicator_1 = require('../drop-indicator/drop-indicator');
var pinboard_panel_1 = require('../pinboard-panel/pinboard-panel');
var index_2 = require('../../visualizations/index');
var CubeView = (function (_super) {
    __extends(CubeView, _super);
    function CubeView() {
        var _this = this;
        _super.call(this);
        this.state = {
            essence: null,
            dragOver: false
        };
        var clicker = {
            changeFilter: function (filter, colors) {
                var essence = _this.state.essence;
                essence = essence.changeFilter(filter);
                if (colors)
                    essence = essence.changeColors(colors);
                _this.setState({ essence: essence });
            },
            changeTimeSelection: function (selection) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeTimeSelection(selection) });
            },
            changeSplits: function (splits, strategy, colors) {
                var essence = _this.state.essence;
                if (colors)
                    essence = essence.changeColors(colors);
                _this.setState({ essence: essence.changeSplits(splits, strategy) });
            },
            changeSplit: function (split, strategy) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeSplit(split, strategy) });
            },
            addSplit: function (split, strategy) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.addSplit(split, strategy) });
            },
            removeSplit: function (split, strategy) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.removeSplit(split, strategy) });
            },
            changeColors: function (colors) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeColors(colors) });
            },
            changeVisualization: function (visualization) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeVisualization(visualization) });
            },
            pin: function (dimension) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.pin(dimension) });
            },
            unpin: function (dimension) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.unpin(dimension) });
            },
            changePinnedSortMeasure: function (measure) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changePinnedSortMeasure(measure) });
            },
            toggleMeasure: function (measure) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.toggleMeasure(measure) });
            },
            changeHighlight: function (owner, delta) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeHighlight(owner, delta) });
            },
            acceptHighlight: function () {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.acceptHighlight() });
            },
            dropHighlight: function () {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.dropHighlight() });
            }
        };
        this.clicker = clicker;
        this.globalResizeListener = this.globalResizeListener.bind(this);
        this.globalKeyDownListener = this.globalKeyDownListener.bind(this);
        window.autoRefresh = function () {
            setInterval(function () {
                var essence = _this.state.essence;
                var dataSource = essence.dataSource;
                if (!dataSource.shouldUpdateMaxTime())
                    return;
                index_1.DataSource.updateMaxTime(dataSource).then(function (updatedDataSource) {
                    console.log("Updated MaxTime for '" + updatedDataSource.name + "'");
                    _this.setState({ essence: essence.updateDataSource(updatedDataSource) });
                });
            }, 1000);
        };
    }
    CubeView.prototype.componentWillMount = function () {
        var _a = this.props, hash = _a.hash, dataSource = _a.dataSource, updateViewHash = _a.updateViewHash;
        var essence = this.getEssenceFromHash(hash);
        if (!essence) {
            essence = this.getEssenceFromDataSource(dataSource);
            updateViewHash(essence.toHash());
        }
        this.setState({ essence: essence });
    };
    CubeView.prototype.componentDidMount = function () {
        drag_manager_1.DragManager.init();
        window.addEventListener('resize', this.globalResizeListener);
        window.addEventListener('keydown', this.globalKeyDownListener);
        this.globalResizeListener();
    };
    CubeView.prototype.componentWillReceiveProps = function (nextProps) {
        var _a = this.props, hash = _a.hash, dataSource = _a.dataSource;
        var essence = this.state.essence;
        if (hash !== nextProps.hash) {
            var hashEssence = this.getEssenceFromHash(nextProps.hash);
            this.setState({ essence: hashEssence });
        }
        else if (!dataSource.equals(nextProps.dataSource)) {
            var newEssence = essence.updateDataSource(nextProps.dataSource);
            this.setState({ essence: newEssence });
        }
    };
    CubeView.prototype.componentWillUpdate = function (nextProps, nextState) {
        var updateViewHash = this.props.updateViewHash;
        var essence = this.state.essence;
        if (updateViewHash && !nextState.essence.equals(essence)) {
            updateViewHash(nextState.essence.toHash());
        }
    };
    CubeView.prototype.componentWillUnmount = function () {
        window.removeEventListener('resize', this.globalResizeListener);
        window.removeEventListener('keydown', this.globalKeyDownListener);
    };
    CubeView.prototype.getEssenceFromDataSource = function (dataSource) {
        return index_1.Essence.fromDataSource(dataSource, { dataSource: dataSource, visualizations: index_2.visualizations });
    };
    CubeView.prototype.getEssenceFromHash = function (hash) {
        if (!hash)
            return null;
        var dataSource = this.props.dataSource;
        return index_1.Essence.fromHash(hash, { dataSource: dataSource, visualizations: index_2.visualizations });
    };
    CubeView.prototype.globalKeyDownListener = function (e) {
        // Shortcuts will go here one day
    };
    CubeView.prototype.globalResizeListener = function () {
        var _a = this.refs, container = _a.container, visualization = _a.visualization;
        var containerDOM = ReactDOM.findDOMNode(container);
        var visualizationDOM = ReactDOM.findDOMNode(visualization);
        if (!containerDOM || !visualizationDOM)
            return;
        this.setState({
            menuStage: index_1.Stage.fromClientRect(containerDOM.getBoundingClientRect()),
            visualizationStage: index_1.Stage.fromClientRect(visualizationDOM.getBoundingClientRect())
        });
    };
    CubeView.prototype.canDrop = function (e) {
        return Boolean(drag_manager_1.DragManager.getDragDimension());
    };
    CubeView.prototype.dragOver = function (e) {
        if (!this.canDrop(e))
            return;
        e.dataTransfer.dropEffect = 'move';
        e.preventDefault();
    };
    CubeView.prototype.dragEnter = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver) {
            this.dragCounter = 0;
            this.setState({ dragOver: true });
        }
        else {
            this.dragCounter++;
        }
    };
    CubeView.prototype.dragLeave = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver)
            return;
        if (this.dragCounter === 0) {
            this.setState({ dragOver: false });
        }
        else {
            this.dragCounter--;
        }
    };
    CubeView.prototype.drop = function (e) {
        if (!this.canDrop(e))
            return;
        e.preventDefault();
        var essence = this.state.essence;
        this.dragCounter = 0;
        var dimension = drag_manager_1.DragManager.getDragDimension();
        if (dimension) {
            this.clicker.changeSplit(index_1.SplitCombine.fromExpression(dimension.expression), index_1.VisStrategy.FairGame);
        }
        this.setState({ dragOver: false });
    };
    CubeView.prototype.triggerFilterMenu = function (dimension) {
        if (!dimension)
            return;
        this.refs['filterTile'].filterMenuRequest(dimension);
    };
    CubeView.prototype.triggerSplitMenu = function (dimension) {
        if (!dimension)
            return;
        this.refs['splitTile'].splitMenuRequest(dimension);
    };
    CubeView.prototype.render = function () {
        var clicker = this.clicker;
        var _a = this.props, getUrlPrefix = _a.getUrlPrefix, onNavClick = _a.onNavClick, user = _a.user;
        var _b = this.state, essence = _b.essence, menuStage = _b.menuStage, visualizationStage = _b.visualizationStage, dragOver = _b.dragOver;
        if (!essence)
            return null;
        var visualization = essence.visualization;
        var visElement = null;
        if (essence.visResolve.isReady() && visualizationStage) {
            var visProps = {
                clicker: clicker,
                essence: essence,
                stage: visualizationStage
            };
            visElement = React.createElement(visualization, visProps);
        }
        var manualFallback = null;
        if (essence.visResolve.isManual()) {
            manualFallback = React.createElement(manual_fallback_1.ManualFallback, {
                clicker: clicker,
                essence: essence
            });
        }
        var dropIndicator = null;
        if (dragOver) {
            dropIndicator = <drop_indicator_1.DropIndicator />;
        }
        return <div className='cube-view'>
      <cube_header_bar_1.CubeHeaderBar dataSource={essence.dataSource} user={user} onNavClick={onNavClick} getUrlPrefix={getUrlPrefix}/>
      <div className="container" ref='container'>
        <dimension_measure_panel_1.DimensionMeasurePanel clicker={clicker} essence={essence} menuStage={menuStage} triggerFilterMenu={this.triggerFilterMenu.bind(this)} triggerSplitMenu={this.triggerSplitMenu.bind(this)} getUrlPrefix={getUrlPrefix}/>
        <div className='center-panel'>
          <div className='center-top-bar'>
            <div className='filter-split-section'>
              <filter_tile_1.FilterTile ref="filterTile" clicker={clicker} essence={essence} menuStage={visualizationStage} getUrlPrefix={getUrlPrefix}/>
              <split_tile_1.SplitTile ref="splitTile" clicker={clicker} essence={essence} menuStage={visualizationStage} getUrlPrefix={getUrlPrefix}/>
            </div>
            <vis_selector_1.VisSelector clicker={clicker} essence={essence}/>
          </div>
          <div className='center-main' onDragOver={this.dragOver.bind(this)} onDragEnter={this.dragEnter.bind(this)} onDragLeave={this.dragLeave.bind(this)} onDrop={this.drop.bind(this)}>
            <div className='visualization' ref='visualization'>{visElement}</div>
            {manualFallback}
            {dropIndicator}
          </div>
        </div>
        <pinboard_panel_1.PinboardPanel clicker={clicker} essence={essence} getUrlPrefix={getUrlPrefix}/>
      </div>
    </div>;
    };
    CubeView.defaultProps = {
        maxFilters: 20,
        maxSplits: 3
    };
    return CubeView;
}(React.Component));
exports.CubeView = CubeView;
//# sourceMappingURL=cube-view.js.map