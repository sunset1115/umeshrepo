"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./split-tile.css');
var React = require('react');
var ReactDOM = require('react-dom');
var svg_icon_1 = require('../svg-icon/svg-icon');
var constants_1 = require('../../config/constants');
var index_1 = require('../../../common/models/index');
var general_1 = require('../../../common/utils/general/general');
var dom_1 = require('../../utils/dom/dom');
var drag_manager_1 = require('../../utils/drag-manager/drag-manager');
var fancy_drag_indicator_1 = require('../fancy-drag-indicator/fancy-drag-indicator');
var SPLIT_CLASS_NAME = 'split';
var SplitTile = (function (_super) {
    __extends(SplitTile, _super);
    function SplitTile() {
        _super.call(this);
        this.state = {
            SplitMenuAsync: null,
            menuOpenOn: null,
            menuDimension: null,
            dragOver: false,
            dragInsertPosition: null,
            dragReplacePosition: null
        };
    }
    SplitTile.prototype.componentDidMount = function () {
        var _this = this;
        require.ensure(['../split-menu/split-menu'], function (require) {
            _this.setState({
                SplitMenuAsync: require('../split-menu/split-menu').SplitMenu
            });
        }, 'split-menu');
    };
    SplitTile.prototype.selectDimensionSplit = function (dimension, split, e) {
        var target = dom_1.findParentWithClass(e.target, SPLIT_CLASS_NAME);
        this.openMenu(dimension, split, target);
    };
    SplitTile.prototype.openMenu = function (dimension, split, target) {
        var menuOpenOn = this.state.menuOpenOn;
        if (menuOpenOn === target) {
            this.closeMenu();
            return;
        }
        this.setState({
            menuOpenOn: target,
            menuDimension: dimension,
            menuSplit: split
        });
    };
    SplitTile.prototype.closeMenu = function () {
        var menuOpenOn = this.state.menuOpenOn;
        if (!menuOpenOn)
            return;
        this.setState({
            menuOpenOn: null,
            menuDimension: null,
            menuSplit: null
        });
    };
    SplitTile.prototype.removeSplit = function (split, e) {
        var clicker = this.props.clicker;
        clicker.removeSplit(split, index_1.VisStrategy.FairGame);
        this.closeMenu();
        e.stopPropagation();
    };
    SplitTile.prototype.dragStart = function (dimension, split, splitIndex, e) {
        var _a = this.props, essence = _a.essence, getUrlPrefix = _a.getUrlPrefix;
        var dataTransfer = e.dataTransfer;
        dataTransfer.effectAllowed = 'all';
        if (getUrlPrefix) {
            var newUrl = essence.changeSplit(index_1.SplitCombine.fromExpression(dimension.expression), index_1.VisStrategy.FairGame).getURL(getUrlPrefix());
            dataTransfer.setData("text/url-list", newUrl);
            dataTransfer.setData("text/plain", newUrl);
        }
        drag_manager_1.DragManager.setDragSplit(split);
        drag_manager_1.DragManager.setDragDimension(dimension);
        dom_1.setDragGhost(dataTransfer, dimension.title);
        this.closeMenu();
    };
    SplitTile.prototype.calculateDragPosition = function (e) {
        var essence = this.props.essence;
        var numItems = essence.splits.length();
        var rect = ReactDOM.findDOMNode(this.refs['items']).getBoundingClientRect();
        var x = dom_1.getXFromEvent(e);
        var offset = x - rect.left;
        return general_1.calculateDragPosition(offset, numItems, constants_1.CORE_ITEM_WIDTH, constants_1.CORE_ITEM_GAP);
    };
    SplitTile.prototype.canDrop = function (e) {
        return Boolean(drag_manager_1.DragManager.getDragSplit() || drag_manager_1.DragManager.getDragDimension());
    };
    SplitTile.prototype.dragOver = function (e) {
        if (!this.canDrop(e))
            return;
        e.dataTransfer.dropEffect = 'move';
        e.preventDefault();
        this.setState(this.calculateDragPosition(e));
    };
    SplitTile.prototype.dragEnter = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver) {
            this.dragCounter = 0;
            var newState = this.calculateDragPosition(e);
            newState.dragOver = true;
            this.setState(newState);
        }
        else {
            this.dragCounter++;
        }
    };
    SplitTile.prototype.dragLeave = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver)
            return;
        if (this.dragCounter === 0) {
            this.setState({
                dragOver: false,
                dragInsertPosition: null,
                dragReplacePosition: null
            });
        }
        else {
            this.dragCounter--;
        }
    };
    SplitTile.prototype.drop = function (e) {
        if (!this.canDrop(e))
            return;
        e.preventDefault();
        var _a = this.props, clicker = _a.clicker, essence = _a.essence;
        var splits = essence.splits;
        var newSplitCombine = null;
        if (drag_manager_1.DragManager.getDragSplit()) {
            newSplitCombine = drag_manager_1.DragManager.getDragSplit();
        }
        else if (drag_manager_1.DragManager.getDragDimension()) {
            newSplitCombine = index_1.SplitCombine.fromExpression(drag_manager_1.DragManager.getDragDimension().expression);
        }
        if (newSplitCombine) {
            var _b = this.calculateDragPosition(e), dragReplacePosition = _b.dragReplacePosition, dragInsertPosition = _b.dragInsertPosition;
            if (dragReplacePosition !== null) {
                clicker.changeSplits(splits.replaceByIndex(dragReplacePosition, newSplitCombine), index_1.VisStrategy.FairGame);
            }
            else if (dragInsertPosition !== null) {
                clicker.changeSplits(splits.insertByIndex(dragInsertPosition, newSplitCombine), index_1.VisStrategy.FairGame);
            }
        }
        this.dragCounter = 0;
        this.setState({
            dragOver: false,
            dragInsertPosition: null,
            dragReplacePosition: null
        });
    };
    // This will be called externally
    SplitTile.prototype.splitMenuRequest = function (dimension) {
        var splits = this.props.essence.splits;
        var split = splits.findSplitForDimension(dimension);
        if (!split)
            return;
        var targetRef = this.refs[dimension.name];
        if (!targetRef)
            return;
        var target = ReactDOM.findDOMNode(targetRef);
        if (!target)
            return;
        this.openMenu(dimension, split, target);
    };
    SplitTile.prototype.renderMenu = function () {
        var _a = this.props, essence = _a.essence, clicker = _a.clicker, menuStage = _a.menuStage;
        var _b = this.state, SplitMenuAsync = _b.SplitMenuAsync, menuOpenOn = _b.menuOpenOn, menuDimension = _b.menuDimension, menuSplit = _b.menuSplit;
        if (!SplitMenuAsync || !menuDimension)
            return null;
        var onClose = this.closeMenu.bind(this);
        return <SplitMenuAsync clicker={clicker} essence={essence} direction="down" containerStage={menuStage} openOn={menuOpenOn} dimension={menuDimension} split={menuSplit} onClose={onClose}/>;
    };
    SplitTile.prototype.render = function () {
        var _this = this;
        var essence = this.props.essence;
        var _a = this.state, menuDimension = _a.menuDimension, dragOver = _a.dragOver, dragInsertPosition = _a.dragInsertPosition, dragReplacePosition = _a.dragReplacePosition;
        var dataSource = essence.dataSource, splits = essence.splits;
        var sectionWidth = constants_1.CORE_ITEM_WIDTH + constants_1.CORE_ITEM_GAP;
        var itemX = 0;
        var splitItems = splits.toArray().map(function (split, i) {
            var dimension = split.getDimension(dataSource.dimensions);
            if (!dimension)
                throw new Error('dimension not found');
            var dimensionName = dimension.name;
            var style = dom_1.transformStyle(itemX, 0);
            itemX += sectionWidth;
            var classNames = [
                SPLIT_CLASS_NAME,
                'type-' + dimension.className
            ];
            if (dimension === menuDimension)
                classNames.push('selected');
            return <div className={classNames.join(' ')} key={split.toKey()} ref={dimensionName} draggable={true} onClick={_this.selectDimensionSplit.bind(_this, dimension, split)} onDragStart={_this.dragStart.bind(_this, dimension, split, i)} style={style}>
        <div className="reading">{split.getTitle(dataSource.dimensions)}</div>
        <div className="remove" onClick={_this.removeSplit.bind(_this, split)}>
          <svg_icon_1.SvgIcon svg={require('../../icons/x.svg')}/>
        </div>
      </div>;
        }, this);
        var fancyDragIndicator = null;
        if (dragInsertPosition !== null || dragReplacePosition !== null) {
            fancyDragIndicator = React.createElement(fancy_drag_indicator_1.FancyDragIndicator, {
                dragInsertPosition: dragInsertPosition,
                dragReplacePosition: dragReplacePosition
            });
        }
        return <div className={'split-tile ' + (dragOver ? 'drag-over' : 'no-drag')} onDragOver={this.dragOver.bind(this)} onDragEnter={this.dragEnter.bind(this)} onDragLeave={this.dragLeave.bind(this)} onDrop={this.drop.bind(this)}>
      <div className="title">{constants_1.STRINGS.split}</div>
      <div className="items" ref="items">
        {splitItems}
      </div>
      {fancyDragIndicator}
      {this.renderMenu()}
    </div>;
    };
    return SplitTile;
}(React.Component));
exports.SplitTile = SplitTile;
//# sourceMappingURL=split-tile.js.map