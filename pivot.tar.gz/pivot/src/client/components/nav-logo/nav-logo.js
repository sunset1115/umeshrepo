"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./nav-logo.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var NavLogo = (function (_super) {
    __extends(NavLogo, _super);
    function NavLogo() {
        _super.call(this);
        // this.state = {};
    }
    NavLogo.prototype.render = function () {
        var onClick = this.props.onClick;
        return <div className="nav-logo" onClick={onClick}>
      <div className="logo">
        <svg_icon_1.SvgIcon svg={require('../../icons/pivot-logo.svg')}/>
      </div>
    </div>;
    };
    return NavLogo;
}(React.Component));
exports.NavLogo = NavLogo;
//# sourceMappingURL=nav-logo.js.map