"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./filter-tile.css');
var React = require('react');
var ReactDOM = require('react-dom');
var Q = require('q');
var constants_1 = require('../../config/constants');
var index_1 = require('../../../common/models/index');
var general_1 = require('../../../common/utils/general/general');
var date_1 = require('../../utils/date/date');
var dom_1 = require('../../utils/dom/dom');
var drag_manager_1 = require('../../utils/drag-manager/drag-manager');
var svg_icon_1 = require('../svg-icon/svg-icon');
var fancy_drag_indicator_1 = require('../fancy-drag-indicator/fancy-drag-indicator');
var bubble_menu_1 = require('../bubble-menu/bubble-menu');
var FILTER_CLASS_NAME = 'filter';
var ANIMATION_DURATION = 400;
var OVERFLOW_WIDTH = 40;
function formatLabel(dimension, clause, essence) {
    var label = dimension.title;
    switch (dimension.kind) {
        case 'string':
        case 'boolean':
            var setElements = clause.getLiteralSet().elements;
            label += setElements.length > 1 ? " (" + setElements.length + ")" : ": " + setElements[0];
            break;
        case 'time':
            var timeSelection = clause.selection;
            var timeRange = essence.evaluateSelection(timeSelection);
            label = date_1.formatTimeRange(timeRange, essence.timezone, date_1.DisplayYear.IF_DIFF);
            break;
        default:
            throw new Error('unknown kind ' + dimension.kind);
    }
    return label;
}
function formatLabelDummy(dimension) {
    return dimension.title;
}
var FilterTile = (function (_super) {
    __extends(FilterTile, _super);
    function FilterTile() {
        _super.call(this);
        this.overflowMenuId = dom_1.uniqueId('overflow-menu-');
        this.state = {
            FilterMenuAsync: null,
            menuOpenOn: null,
            menuDimension: null,
            menuInside: null,
            overflowMenuOpenOn: null,
            dragOver: false,
            dragInsertPosition: null,
            dragReplacePosition: null,
            possibleDimension: null,
            possibleInsertPosition: null,
            possibleReplacePosition: null,
            maxItems: 20
        };
    }
    FilterTile.prototype.componentDidMount = function () {
        var _this = this;
        require.ensure(['../filter-menu/filter-menu'], function (require) {
            _this.setState({
                FilterMenuAsync: require('../filter-menu/filter-menu').FilterMenu
            });
        }, 'filter-menu');
    };
    FilterTile.prototype.componentWillReceiveProps = function (nextProps) {
        var menuStage = nextProps.menuStage;
        var sectionWidth = constants_1.CORE_ITEM_WIDTH + constants_1.CORE_ITEM_GAP;
        if (menuStage) {
            var newMaxItems = Math.floor((menuStage.width - constants_1.BAR_TITLE_WIDTH - OVERFLOW_WIDTH - 79 + constants_1.CORE_ITEM_GAP) / sectionWidth); // 79 = vis selector width
            if (newMaxItems !== this.state.maxItems) {
                this.setState({
                    menuOpenOn: null,
                    menuDimension: null,
                    menuInside: null,
                    possibleDimension: null,
                    possibleInsertPosition: null,
                    possibleReplacePosition: null,
                    overflowMenuOpenOn: null,
                    maxItems: newMaxItems
                });
            }
        }
    };
    FilterTile.prototype.componentDidUpdate = function () {
        var _a = this.state, possibleDimension = _a.possibleDimension, overflowMenuOpenOn = _a.overflowMenuOpenOn;
        if (possibleDimension) {
            this.dummyDeferred.resolve(null);
        }
        if (overflowMenuOpenOn) {
            var overflowMenu = this.getOverflowMenu();
            if (overflowMenu)
                this.overflowMenuDeferred.resolve(overflowMenu);
        }
    };
    FilterTile.prototype.overflowButtonTarget = function () {
        return ReactDOM.findDOMNode(this.refs['overflow']);
    };
    FilterTile.prototype.getOverflowMenu = function () {
        return document.getElementById(this.overflowMenuId);
    };
    FilterTile.prototype.clickDimension = function (dimension, e) {
        var target = dom_1.findParentWithClass(e.target, FILTER_CLASS_NAME);
        this.openMenu(dimension, target);
    };
    FilterTile.prototype.openMenuOnDimension = function (dimension) {
        var _this = this;
        var targetRef = this.refs[dimension.name];
        if (targetRef) {
            var target = ReactDOM.findDOMNode(targetRef);
            if (!target)
                return;
            this.openMenu(dimension, target);
        }
        else {
            var overflowButtonTarget = this.overflowButtonTarget();
            if (overflowButtonTarget) {
                this.openOverflowMenu(overflowButtonTarget).then(function () {
                    var target = ReactDOM.findDOMNode(_this.refs[dimension.name]);
                    if (!target)
                        return;
                    _this.openMenu(dimension, target);
                });
            }
        }
    };
    FilterTile.prototype.openMenu = function (dimension, target) {
        var menuOpenOn = this.state.menuOpenOn;
        if (menuOpenOn === target) {
            this.closeMenu();
            return;
        }
        var overflowMenu = this.getOverflowMenu();
        var menuInside = null;
        if (overflowMenu && dom_1.isInside(target, overflowMenu)) {
            menuInside = overflowMenu;
        }
        this.setState({
            menuOpenOn: target,
            menuDimension: dimension,
            menuInside: menuInside
        });
    };
    FilterTile.prototype.closeMenu = function () {
        var _a = this.state, menuOpenOn = _a.menuOpenOn, possibleDimension = _a.possibleDimension;
        if (!menuOpenOn)
            return;
        var newState = {
            menuOpenOn: null,
            menuDimension: null,
            menuInside: null,
            possibleDimension: null,
            possibleInsertPosition: null,
            possibleReplacePosition: null
        };
        if (possibleDimension) {
            // If we are adding a ghost dimension also close the overflow menu
            // This is so it does not remain phantom open with nothing inside
            newState.overflowMenuOpenOn = null;
        }
        this.setState(newState);
    };
    FilterTile.prototype.openOverflowMenu = function (target) {
        if (!target)
            return;
        var overflowMenuOpenOn = this.state.overflowMenuOpenOn;
        if (overflowMenuOpenOn === target) {
            this.closeOverflowMenu();
            return;
        }
        this.overflowMenuDeferred = Q.defer();
        this.setState({ overflowMenuOpenOn: target });
        return this.overflowMenuDeferred.promise;
    };
    FilterTile.prototype.closeOverflowMenu = function () {
        var overflowMenuOpenOn = this.state.overflowMenuOpenOn;
        if (!overflowMenuOpenOn)
            return;
        this.setState({
            overflowMenuOpenOn: null
        });
    };
    FilterTile.prototype.removeFilter = function (itemBlank, e) {
        var _a = this.props, essence = _a.essence, clicker = _a.clicker;
        if (itemBlank.clause) {
            if (itemBlank.source === 'from-highlight') {
                clicker.dropHighlight();
            }
            else {
                clicker.changeFilter(essence.filter.remove(itemBlank.clause.expression));
            }
        }
        this.closeMenu();
        this.closeOverflowMenu();
        e.stopPropagation();
    };
    FilterTile.prototype.dragStart = function (dimension, clause, e) {
        var _a = this.props, essence = _a.essence, getUrlPrefix = _a.getUrlPrefix;
        var dataTransfer = e.dataTransfer;
        dataTransfer.effectAllowed = 'all';
        if (getUrlPrefix) {
            var newUrl = essence.getURL(getUrlPrefix());
            dataTransfer.setData("text/url-list", newUrl);
            dataTransfer.setData("text/plain", newUrl);
        }
        drag_manager_1.DragManager.setDragDimension(dimension);
        dom_1.setDragGhost(dataTransfer, dimension.title);
        this.closeMenu();
        this.closeOverflowMenu();
    };
    FilterTile.prototype.calculateDragPosition = function (e) {
        var essence = this.props.essence;
        var numItems = essence.filter.length();
        var rect = ReactDOM.findDOMNode(this.refs['items']).getBoundingClientRect();
        var offset = dom_1.getXFromEvent(e) - rect.left;
        return general_1.calculateDragPosition(offset, numItems, constants_1.CORE_ITEM_WIDTH, constants_1.CORE_ITEM_GAP);
    };
    FilterTile.prototype.canDrop = function (e) {
        return Boolean(drag_manager_1.DragManager.getDragDimension());
    };
    FilterTile.prototype.dragOver = function (e) {
        if (!this.canDrop(e))
            return;
        e.dataTransfer.dropEffect = 'move';
        e.preventDefault();
        this.setState(this.calculateDragPosition(e));
    };
    FilterTile.prototype.dragEnter = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver) {
            this.dragCounter = 0;
            var newState = this.calculateDragPosition(e);
            newState.dragOver = true;
            this.setState(newState);
        }
        else {
            this.dragCounter++;
        }
    };
    FilterTile.prototype.dragLeave = function (e) {
        if (!this.canDrop(e))
            return;
        var dragOver = this.state.dragOver;
        if (!dragOver)
            return;
        if (this.dragCounter === 0) {
            this.setState({
                dragOver: false,
                dragInsertPosition: null,
                dragReplacePosition: null
            });
        }
        else {
            this.dragCounter--;
        }
    };
    FilterTile.prototype.drop = function (e) {
        var _this = this;
        if (!this.canDrop(e))
            return;
        e.preventDefault();
        var _a = this.props, clicker = _a.clicker, essence = _a.essence;
        var filter = essence.filter, dataSource = essence.dataSource;
        var newState = {
            dragOver: false,
            dragInsertPosition: null,
            dragReplacePosition: null
        };
        var dimension = drag_manager_1.DragManager.getDragDimension();
        if (dimension) {
            var _b = this.calculateDragPosition(e), dragReplacePosition = _b.dragReplacePosition, dragInsertPosition = _b.dragInsertPosition;
            var tryingToReplaceTime = false;
            if (dragReplacePosition !== null) {
                var targetClause = filter.clauses.get(dragReplacePosition);
                tryingToReplaceTime = targetClause && targetClause.expression.equals(dataSource.timeAttribute);
            }
            var existingClause = filter.clauseForExpression(dimension.expression);
            if (existingClause) {
                var newFilter;
                if (dragReplacePosition !== null) {
                    newFilter = filter.replaceByIndex(dragReplacePosition, existingClause);
                }
                else if (dragInsertPosition !== null) {
                    newFilter = filter.insertByIndex(dragInsertPosition, existingClause);
                }
                if (filter.equals(newFilter)) {
                    this.filterMenuRequest(dimension);
                }
                else {
                    clicker.changeFilter(newFilter);
                    setTimeout(function () {
                        _this.filterMenuRequest(dimension);
                    }, ANIMATION_DURATION + 50); // Wait for the animation to finish to know where to open the menu;
                }
            }
            else {
                if ((dragInsertPosition !== null || dragReplacePosition !== null) && !tryingToReplaceTime) {
                    this.addDummy(dimension, dragInsertPosition, dragReplacePosition);
                }
            }
        }
        this.dragCounter = 0;
        this.setState(newState);
    };
    FilterTile.prototype.addDummy = function (dimension, possibleInsertPosition, possibleReplacePosition) {
        var _this = this;
        this.dummyDeferred = Q.defer();
        this.setState({
            possibleDimension: dimension,
            possibleInsertPosition: possibleInsertPosition,
            possibleReplacePosition: possibleReplacePosition
        });
        this.dummyDeferred.promise.then(function () {
            _this.openMenuOnDimension(dimension);
        });
    };
    // This will be called externally
    FilterTile.prototype.filterMenuRequest = function (dimension) {
        var filter = this.props.essence.filter;
        if (filter.filteredOn(dimension.expression)) {
            this.openMenuOnDimension(dimension);
        }
        else {
            this.addDummy(dimension, filter.length(), null);
        }
    };
    FilterTile.prototype.overflowButtonClick = function () {
        this.openOverflowMenu(this.overflowButtonTarget());
    };
    ;
    FilterTile.prototype.renderMenu = function () {
        var _a = this.props, essence = _a.essence, clicker = _a.clicker, menuStage = _a.menuStage;
        var _b = this.state, FilterMenuAsync = _b.FilterMenuAsync, menuOpenOn = _b.menuOpenOn, menuDimension = _b.menuDimension, menuInside = _b.menuInside, possibleInsertPosition = _b.possibleInsertPosition, possibleReplacePosition = _b.possibleReplacePosition, maxItems = _b.maxItems, overflowMenuOpenOn = _b.overflowMenuOpenOn;
        if (!FilterMenuAsync || !menuDimension)
            return null;
        if (possibleReplacePosition === maxItems) {
            possibleInsertPosition = possibleReplacePosition;
            possibleReplacePosition = null;
        }
        return <FilterMenuAsync clicker={clicker} essence={essence} direction="down" containerStage={overflowMenuOpenOn ? null : menuStage} openOn={menuOpenOn} dimension={menuDimension} insertPosition={possibleInsertPosition} replacePosition={possibleReplacePosition} onClose={this.closeMenu.bind(this)} inside={menuInside}/>;
    };
    FilterTile.prototype.renderOverflowMenu = function (overflowItemBlanks) {
        var _this = this;
        var overflowMenuOpenOn = this.state.overflowMenuOpenOn;
        if (!overflowMenuOpenOn)
            return null;
        var segmentHeight = 29 + constants_1.CORE_ITEM_GAP;
        var itemY = constants_1.CORE_ITEM_GAP;
        var filterItems = overflowItemBlanks.map(function (itemBlank) {
            var style = dom_1.transformStyle(0, itemY);
            itemY += segmentHeight;
            return _this.renderItemBlank(itemBlank, style);
        });
        return <bubble_menu_1.BubbleMenu className="overflow-menu" id={this.overflowMenuId} direction="down" stage={index_1.Stage.fromSize(208, itemY)} fixedSize={true} openOn={overflowMenuOpenOn} onClose={this.closeOverflowMenu.bind(this)}>
      {filterItems}
    </bubble_menu_1.BubbleMenu>;
    };
    FilterTile.prototype.renderOverflow = function (overflowItemBlanks) {
        return <div className="overflow" ref="overflow" onClick={this.overflowButtonClick.bind(this)}>
      {'+' + overflowItemBlanks.length}
      {this.renderOverflowMenu(overflowItemBlanks)}
    </div>;
    };
    FilterTile.prototype.renderRemoveButton = function (itemBlank) {
        var essence = this.props.essence;
        var dataSource = essence.dataSource;
        if (itemBlank.dimension.expression.equals(dataSource.timeAttribute))
            return null;
        return <div className="remove" onClick={this.removeFilter.bind(this, itemBlank)}>
      <svg_icon_1.SvgIcon svg={require('../../icons/x.svg')}/>
    </div>;
    };
    FilterTile.prototype.renderItemBlank = function (itemBlank, style) {
        var _a = this.props, essence = _a.essence, clicker = _a.clicker;
        var menuDimension = this.state.menuDimension;
        var timezone = essence.timezone;
        var dimension = itemBlank.dimension, clause = itemBlank.clause, source = itemBlank.source;
        var dimensionName = dimension.name;
        var classNames = [FILTER_CLASS_NAME, 'type-' + dimension.className, source];
        if (dimension === menuDimension)
            classNames.push('selected');
        var className = classNames.join(' ');
        if (source === 'from-highlight') {
            return <div className={className} key={dimensionName} ref={dimensionName} onClick={clicker.acceptHighlight.bind(clicker)} style={style}>
        <div className="reading">{formatLabel(dimension, clause, essence)}</div>
        {this.renderRemoveButton(itemBlank)}
      </div>;
        }
        if (clause) {
            return <div className={className} key={dimensionName} ref={dimensionName} draggable={true} onClick={this.clickDimension.bind(this, dimension)} onDragStart={this.dragStart.bind(this, dimension, clause)} style={style}>
        <div className="reading">{formatLabel(dimension, clause, essence)}</div>
        {this.renderRemoveButton(itemBlank)}
      </div>;
        }
        else {
            return <div className={className} key={dimensionName} ref={dimensionName} style={style}>
        <div className="reading">{formatLabelDummy(dimension)}</div>
        {this.renderRemoveButton(itemBlank)}
      </div>;
        }
    };
    FilterTile.prototype.render = function () {
        var _this = this;
        var essence = this.props.essence;
        var _a = this.state, dragOver = _a.dragOver, dragInsertPosition = _a.dragInsertPosition, dragReplacePosition = _a.dragReplacePosition, possibleDimension = _a.possibleDimension, possibleInsertPosition = _a.possibleInsertPosition, possibleReplacePosition = _a.possibleReplacePosition, maxItems = _a.maxItems;
        var dataSource = essence.dataSource, filter = essence.filter, highlight = essence.highlight;
        var sectionWidth = constants_1.CORE_ITEM_WIDTH + constants_1.CORE_ITEM_GAP;
        var itemBlanks = filter.clauses.toArray()
            .map(function (clause) {
            var dimension = dataSource.getDimensionByExpression(clause.expression);
            if (!dimension)
                return null;
            return {
                dimension: dimension,
                source: 'from-filter',
                clause: clause
            };
        })
            .filter(Boolean);
        if (highlight) {
            highlight.delta.clauses.forEach(function (clause) {
                var added = false;
                itemBlanks = itemBlanks.map(function (blank) {
                    if (clause.expression.equals(blank.clause.expression)) {
                        added = true;
                        return {
                            dimension: blank.dimension,
                            source: 'from-highlight',
                            clause: clause
                        };
                    }
                    else {
                        return blank;
                    }
                });
                if (!added) {
                    var dimension = dataSource.getDimensionByExpression(clause.expression);
                    if (dimension) {
                        itemBlanks.push({
                            dimension: dimension,
                            source: 'from-highlight',
                            clause: clause
                        });
                    }
                }
            });
        }
        if (possibleDimension) {
            var dummyBlank = {
                dimension: possibleDimension,
                source: 'from-drag'
            };
            if (possibleReplacePosition === maxItems) {
                possibleInsertPosition = possibleReplacePosition;
                possibleReplacePosition = null;
            }
            if (possibleInsertPosition !== null) {
                itemBlanks.splice(possibleInsertPosition, 0, dummyBlank);
            }
            if (possibleReplacePosition !== null) {
                itemBlanks[possibleReplacePosition] = dummyBlank;
            }
        }
        var overflowItemBlanks;
        if (maxItems < itemBlanks.length) {
            overflowItemBlanks = itemBlanks.slice(maxItems);
            itemBlanks = itemBlanks.slice(0, maxItems);
        }
        else {
            overflowItemBlanks = [];
        }
        var itemX = 0;
        var filterItems = itemBlanks.map(function (itemBlank) {
            var style = dom_1.transformStyle(itemX, 0);
            itemX += sectionWidth;
            return _this.renderItemBlank(itemBlank, style);
        });
        var overflowIndicator = null;
        if (overflowItemBlanks.length) {
            overflowIndicator = this.renderOverflow(overflowItemBlanks);
        }
        var fancyDragIndicator = null;
        if (dragInsertPosition !== null || dragReplacePosition !== null) {
            fancyDragIndicator = <fancy_drag_indicator_1.FancyDragIndicator dragInsertPosition={dragInsertPosition} dragReplacePosition={dragReplacePosition}/>;
        }
        var className = [
            'filter-tile',
            overflowIndicator ? 'has-overflow' : 'no-overflow',
            (dragOver ? 'drag-over' : 'no-drag')
        ].join(' ');
        return <div className={className} onDragOver={this.dragOver.bind(this)} onDragEnter={this.dragEnter.bind(this)} onDragLeave={this.dragLeave.bind(this)} onDrop={this.drop.bind(this)}>
      <div className="title">{constants_1.STRINGS.filter}</div>
      <div className="items" ref="items">
        {filterItems}
      </div>
      {overflowIndicator}
      {fancyDragIndicator}
      {this.renderMenu()}
    </div>;
    };
    return FilterTile;
}(React.Component));
exports.FilterTile = FilterTile;
//# sourceMappingURL=filter-tile.js.map