"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./fancy-drag-indicator.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var constants_1 = require('../../config/constants');
var FancyDragIndicator = (function (_super) {
    __extends(FancyDragIndicator, _super);
    function FancyDragIndicator() {
        _super.call(this);
        // this.state = {};
    }
    FancyDragIndicator.prototype.render = function () {
        var _a = this.props, dragInsertPosition = _a.dragInsertPosition, dragReplacePosition = _a.dragReplacePosition;
        var sectionWidth = constants_1.CORE_ITEM_WIDTH + constants_1.CORE_ITEM_GAP;
        var ghostArrowLeft;
        if (dragInsertPosition !== null) {
            ghostArrowLeft = dragInsertPosition * sectionWidth - constants_1.CORE_ITEM_GAP / 2;
        }
        else {
            ghostArrowLeft = dragReplacePosition * sectionWidth + constants_1.CORE_ITEM_WIDTH / 2;
        }
        var dragGhostElement = null;
        if (dragReplacePosition !== null) {
            var left = dragReplacePosition * sectionWidth;
            dragGhostElement = <div className="drag-ghost-element" style={{ left: left }}></div>;
        }
        return <div className="fancy-drag-indicator">
      {dragGhostElement}
      <svg_icon_1.SvgIcon className="drag-ghost-arrow" svg={require('../../icons/drag-arrow.svg')} style={{ left: ghostArrowLeft }}/>
    </div>;
    };
    return FancyDragIndicator;
}(React.Component));
exports.FancyDragIndicator = FancyDragIndicator;
//# sourceMappingURL=fancy-drag-indicator.js.map