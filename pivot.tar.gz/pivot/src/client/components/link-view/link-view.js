"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./link-view.css');
var React = require('react');
var ReactDOM = require('react-dom');
var index_1 = require('../../../common/models/index');
// import { ... } from '../../config/constants';
var link_header_bar_1 = require('../link-header-bar/link-header-bar');
var manual_fallback_1 = require('../manual-fallback/manual-fallback');
var pinboard_panel_1 = require('../pinboard-panel/pinboard-panel');
var LinkView = (function (_super) {
    __extends(LinkView, _super);
    function LinkView() {
        var _this = this;
        _super.call(this);
        this.state = {
            linkItem: null,
            essence: null,
            visualizationStage: null,
            menuStage: null
        };
        var clicker = {
            changeFilter: function (filter, colors) {
                var essence = _this.state.essence;
                essence = essence.changeFilter(filter);
                if (colors)
                    essence = essence.changeColors(colors);
                _this.setState({ essence: essence });
            },
            changeTimeSelection: function (selection) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeTimeSelection(selection) });
            },
            changeColors: function (colors) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeColors(colors) });
            },
            changePinnedSortMeasure: function (measure) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changePinnedSortMeasure(measure) });
            },
            toggleMeasure: function (measure) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.toggleMeasure(measure) });
            },
            changeHighlight: function (owner, delta) {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.changeHighlight(owner, delta) });
            },
            acceptHighlight: function () {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.acceptHighlight() });
            },
            dropHighlight: function () {
                var essence = _this.state.essence;
                _this.setState({ essence: essence.dropHighlight() });
            }
        };
        this.clicker = clicker;
        this.globalResizeListener = this.globalResizeListener.bind(this);
    }
    LinkView.prototype.componentWillMount = function () {
        var _a = this.props, hash = _a.hash, linkViewConfig = _a.linkViewConfig, updateViewHash = _a.updateViewHash;
        var linkItem = linkViewConfig.findByName(hash);
        if (!linkItem) {
            linkItem = linkViewConfig.defaultLinkItem();
            updateViewHash(linkItem.name);
        }
        this.setState({
            linkItem: linkItem,
            essence: linkItem.essence
        });
    };
    LinkView.prototype.componentDidMount = function () {
        window.addEventListener('resize', this.globalResizeListener);
        this.globalResizeListener();
    };
    LinkView.prototype.componentWillReceiveProps = function (nextProps) {
        var _a = this.props, hash = _a.hash, linkViewConfig = _a.linkViewConfig;
        if (hash !== nextProps.hash) {
            var linkItem = linkViewConfig.findByName(hash);
            this.setState({ linkItem: linkItem });
        }
    };
    LinkView.prototype.componentWillUpdate = function (nextProps, nextState) {
        var updateViewHash = this.props.updateViewHash;
        var linkItem = this.state.linkItem;
        if (updateViewHash && !nextState.linkItem.equals(linkItem)) {
            updateViewHash(nextState.linkItem.name);
        }
    };
    LinkView.prototype.componentWillUnmount = function () {
        window.removeEventListener('resize', this.globalResizeListener);
    };
    LinkView.prototype.globalResizeListener = function () {
        var _a = this.refs, container = _a.container, visualization = _a.visualization;
        var containerDOM = ReactDOM.findDOMNode(container);
        var visualizationDOM = ReactDOM.findDOMNode(visualization);
        if (!containerDOM || !visualizationDOM)
            return;
        this.setState({
            menuStage: index_1.Stage.fromClientRect(containerDOM.getBoundingClientRect()),
            visualizationStage: index_1.Stage.fromClientRect(visualizationDOM.getBoundingClientRect())
        });
    };
    LinkView.prototype.selectLinkItem = function (linkItem) {
        this.setState({
            linkItem: linkItem,
            essence: linkItem.essence
        });
    };
    LinkView.prototype.goToCubeView = function () {
        var _a = this.props, changeHash = _a.changeHash, getUrlPrefix = _a.getUrlPrefix;
        var essence = this.state.essence;
        changeHash(essence.dataSource.name + "/" + essence.toHash(), true);
    };
    LinkView.prototype.renderLinkPanel = function () {
        var _this = this;
        var linkViewConfig = this.props.linkViewConfig;
        var linkItem = this.state.linkItem;
        var groupId = 0;
        var lastGroup = null;
        var items = [];
        linkViewConfig.linkItems.forEach(function (li) {
            // Add a group header if needed
            if (lastGroup !== li.group) {
                items.push(<div className="link-group-title" key={'group_' + groupId}>
          {li.group}
        </div>);
                groupId++;
                lastGroup = li.group;
            }
            items.push(<div className={'link-item' + (li === linkItem ? ' selected' : '')} key={'li_' + li.name} onClick={_this.selectLinkItem.bind(_this, li)}>
        {li.title}
      </div>);
        });
        return <div className="link-panel">{items}</div>;
    };
    LinkView.prototype.render = function () {
        var clicker = this.clicker;
        var _a = this.props, getUrlPrefix = _a.getUrlPrefix, onNavClick = _a.onNavClick, linkViewConfig = _a.linkViewConfig, user = _a.user;
        var _b = this.state, linkItem = _b.linkItem, essence = _b.essence, visualizationStage = _b.visualizationStage;
        if (!linkItem)
            return null;
        var visualization = essence.visualization;
        var visElement = null;
        if (essence.visResolve.isReady() && visualizationStage) {
            var visProps = {
                clicker: clicker,
                essence: essence,
                stage: visualizationStage
            };
            visElement = React.createElement(visualization, visProps);
        }
        var manualFallback = null;
        if (essence.visResolve.isManual()) {
            manualFallback = React.createElement(manual_fallback_1.ManualFallback, {
                clicker: clicker,
                essence: essence
            });
        }
        return <div className='link-view'>
      <link_header_bar_1.LinkHeaderBar title={linkViewConfig.title} user={user} onNavClick={onNavClick} onExploreClick={this.goToCubeView.bind(this)} getUrlPrefix={getUrlPrefix}/>
      <div className="container" ref='container'>
        {this.renderLinkPanel()}
        <div className='center-panel'>
          <div className='center-top-bar'>
            <div className='link-title'>{linkItem.title}</div>
            <div className='link-description'>{linkItem.description}</div>
          </div>
          <div className='center-main'>
            <div className='visualization' ref='visualization'>{visElement}</div>
            {manualFallback}
          </div>
        </div>
        <pinboard_panel_1.PinboardPanel clicker={clicker} essence={essence} getUrlPrefix={getUrlPrefix}/>
      </div>
    </div>;
    };
    return LinkView;
}(React.Component));
exports.LinkView = LinkView;
//# sourceMappingURL=link-view.js.map