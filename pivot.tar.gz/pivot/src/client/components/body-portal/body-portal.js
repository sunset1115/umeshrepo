"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./body-portal.css');
var React = require('react');
var ReactDOM = require('react-dom');
var BodyPortal = (function (_super) {
    __extends(BodyPortal, _super);
    function BodyPortal() {
        _super.call(this);
        this.target = null; // HTMLElement, a div that is appended to the body
        this.component = null; // ReactElement, which is mounted on the target
        // this.state = {};
    }
    BodyPortal.prototype.position = function () {
        var _a = this.props, left = _a.left, top = _a.top;
        if (typeof left === 'number') {
            this.target.style.left = Math.round(left) + 'px';
        }
        if (typeof top === 'number') {
            this.target.style.top = Math.round(top) + 'px';
        }
    };
    BodyPortal.prototype.componentDidMount = function () {
        var _a = this.props, fullSize = _a.fullSize, disablePointerEvents = _a.disablePointerEvents;
        var newDiv = document.createElement('div');
        newDiv.className = 'body-portal' + (fullSize ? ' full-size' : '') + (disablePointerEvents ? '' : ' pointer-events');
        this.target = document.body.appendChild(newDiv);
        this.position();
        this.component = ReactDOM.render(this.props.children, this.target);
    };
    BodyPortal.prototype.componentDidUpdate = function () {
        this.position();
        this.component = ReactDOM.render(this.props.children, this.target);
    };
    BodyPortal.prototype.componentWillUnmount = function () {
        ReactDOM.unmountComponentAtNode(this.target);
        document.body.removeChild(this.target);
    };
    BodyPortal.prototype.render = function () {
        return null;
    };
    return BodyPortal;
}(React.Component));
exports.BodyPortal = BodyPortal;
//# sourceMappingURL=body-portal.js.map