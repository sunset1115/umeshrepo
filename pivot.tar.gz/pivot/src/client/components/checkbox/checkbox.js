"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./checkbox.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
var Checkbox = (function (_super) {
    __extends(Checkbox, _super);
    function Checkbox() {
        _super.call(this);
        // this.state = {};
    }
    Checkbox.prototype.render = function () {
        var _a = this.props, selected = _a.selected, onClick = _a.onClick, cross = _a.cross, color = _a.color;
        var className = 'checkbox';
        var style = null;
        if (color) {
            className += ' color';
            style = { background: color };
        }
        var check = null;
        if (selected) {
            if (cross) {
                className += ' cross';
                check = <svg_icon_1.SvgIcon svg={require('../../icons/x.svg')}/>;
            }
            else {
                className += ' check';
                check = <svg_icon_1.SvgIcon svg={require('../../icons/check.svg')}/>;
            }
        }
        return <div className={className} onClick={onClick}>
      <div className="checkbox-body" style={style}></div>
      {check}
    </div>;
    };
    return Checkbox;
}(React.Component));
exports.Checkbox = Checkbox;
//# sourceMappingURL=checkbox.js.map