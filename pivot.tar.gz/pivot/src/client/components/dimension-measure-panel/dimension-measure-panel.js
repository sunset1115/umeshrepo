"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./dimension-measure-panel.css');
var React = require('react');
// import { ... } from '../../config/constants';
// import { SvgIcon } from '../svg-icon/svg-icon';
var dimension_list_tile_1 = require('../dimension-list-tile/dimension-list-tile');
var measures_tile_1 = require('../measures-tile/measures-tile');
var DimensionMeasurePanel = (function (_super) {
    __extends(DimensionMeasurePanel, _super);
    function DimensionMeasurePanel() {
        _super.call(this);
        // this.state = {};
    }
    DimensionMeasurePanel.prototype.render = function () {
        var _a = this.props, clicker = _a.clicker, essence = _a.essence, menuStage = _a.menuStage, triggerFilterMenu = _a.triggerFilterMenu, triggerSplitMenu = _a.triggerSplitMenu, getUrlPrefix = _a.getUrlPrefix;
        return <div className="dimension-measure-panel">
      <dimension_list_tile_1.DimensionListTile clicker={clicker} essence={essence} menuStage={menuStage} triggerFilterMenu={triggerFilterMenu} triggerSplitMenu={triggerSplitMenu} getUrlPrefix={getUrlPrefix}/>
      <measures_tile_1.MeasuresTile clicker={clicker} essence={essence}/>
    </div>;
    };
    return DimensionMeasurePanel;
}(React.Component));
exports.DimensionMeasurePanel = DimensionMeasurePanel;
//# sourceMappingURL=dimension-measure-panel.js.map