"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./vertical-axis.css');
var React = require('react');
var formatter_1 = require('../../../common/utils/formatter/formatter');
var index_1 = require('../../../common/models/index');
// import { SomeComp } from '../some-comp/some-comp';
var TICK_WIDTH = 5;
var TEXT_OFFSET = 2;
var VerticalAxis = (function (_super) {
    __extends(VerticalAxis, _super);
    function VerticalAxis() {
        _super.call(this);
        // this.state = {};
    }
    VerticalAxis.prototype.render = function () {
        var _a = this.props, stage = _a.stage, yTicks = _a.yTicks, scaleY = _a.scaleY;
        var formatter = formatter_1.formatterFromData(yTicks, index_1.Measure.DEFAULT_FORMAT);
        var lines = yTicks.map(function (tick, i) {
            var y = scaleY(tick);
            return <line className="tick" key={String(tick)} x1={0} y1={y} x2={TICK_WIDTH} y2={y}/>;
        });
        var labelX = TICK_WIDTH + TEXT_OFFSET;
        var dy = "0.31em";
        var labels = yTicks.map(function (tick, i) {
            var y = scaleY(tick);
            return <text className="tick" key={String(tick)} x={labelX} y={y} dy={dy}>{formatter(tick)}</text>;
        });
        return <g className="vertical-axis" transform={stage.getTransform()}>
      <line className="border" x1={0} x2={0} y1={0} y2={stage.height}/>
      {lines}
      {labels}
    </g>;
    };
    return VerticalAxis;
}(React.Component));
exports.VerticalAxis = VerticalAxis;
//# sourceMappingURL=vertical-axis.js.map