"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./highlight-controls.css');
var React = require('react');
var svg_icon_1 = require('../svg-icon/svg-icon');
// import { SomeComp } from '../some-comp/some-comp';
function stopEvent(e) {
    e.stopPropagation();
}
var HighlightControls = (function (_super) {
    __extends(HighlightControls, _super);
    function HighlightControls() {
        _super.call(this);
        // this.state = {};
    }
    HighlightControls.prototype.onAccept = function (e) {
        e.stopPropagation();
        var _a = this.props, onClose = _a.onClose, clicker = _a.clicker;
        clicker.acceptHighlight();
        if (onClose)
            onClose();
    };
    HighlightControls.prototype.onCancel = function (e) {
        e.stopPropagation();
        var _a = this.props, onClose = _a.onClose, clicker = _a.clicker;
        clicker.dropHighlight();
        if (onClose)
            onClose();
    };
    HighlightControls.prototype.render = function () {
        var _a = this.props, orientation = _a.orientation, style = _a.style;
        var orientationClass = orientation === 'horizontal' ? 'horizontal' : 'vertical';
        return <div className={'highlight-controls ' + orientationClass} onMouseDown={stopEvent} style={style}>
      <div className="button accept" onClick={this.onAccept.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/check.svg')}/>
      </div>
      <div className="button cancel" onClick={this.onCancel.bind(this)}>
        <svg_icon_1.SvgIcon svg={require('../../icons/x.svg')}/>
      </div>
    </div>;
    };
    return HighlightControls;
}(React.Component));
exports.HighlightControls = HighlightControls;
//# sourceMappingURL=highlight-controls.js.map