"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./nav-list.css');
var React = require('react');
// import { ... } from '../../config/constants';
var svg_icon_1 = require('../svg-icon/svg-icon');
var NavList = (function (_super) {
    __extends(NavList, _super);
    function NavList() {
        _super.apply(this, arguments);
    }
    NavList.prototype.getItemClassName = function (itemName) {
        var selected = this.props.selected;
        var itemClass = "item";
        if (selected && selected === itemName)
            return itemClass + " selected";
        if (itemName === "settings")
            return itemClass + " not-implemented";
        return itemClass;
    };
    NavList.prototype.renderIcon = function (path) {
        if (!path)
            return null;
        return <span className="icon">
      <svg_icon_1.SvgIcon svg={require('../../icons/full-cube.svg')}/>
    </span>;
    };
    NavList.prototype.renderNavList = function () {
        var _this = this;
        return this.props.navItems.map(function (navItem) {
            return <li className={_this.getItemClassName(navItem.name)} key={navItem.name} onClick={_this.props.onSelect.bind(_this, navItem)}>
        {_this.renderIcon(_this.props.icon)}
        {navItem.title}
      </li>;
        });
    };
    NavList.prototype.render = function () {
        var title = this.props.title;
        var className = "nav-list";
        var titleSection = null;
        if (title) {
            titleSection = <div className="group-title">
        {title}
        <ul className="icons not-implemented">
          <li className="icon">
            <svg_icon_1.SvgIcon svg={require('../../icons/full-add.svg')}/>
          </li>
          <li className="icon">
            <svg_icon_1.SvgIcon svg={require('../../icons/full-settings.svg')}/>
          </li>
        </ul>
      </div>;
        }
        else {
            className += " no-title";
        }
        return <div className={className}>
      {titleSection}
      <ul className="items">
        {this.renderNavList()}
      </ul>
    </div>;
    };
    ;
    return NavList;
}(React.Component));
exports.NavList = NavList;
//# sourceMappingURL=nav-list.js.map