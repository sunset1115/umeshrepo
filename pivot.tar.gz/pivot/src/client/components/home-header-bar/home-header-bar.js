"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./home-header-bar.css');
var React = require('react');
// import { ... } from '../../config/constants';
var svg_icon_1 = require('../svg-icon/svg-icon');
var HomeHeaderBar = (function (_super) {
    __extends(HomeHeaderBar, _super);
    function HomeHeaderBar() {
        _super.apply(this, arguments);
    }
    HomeHeaderBar.prototype.render = function () {
        var _a = this.props, user = _a.user, onNavClick = _a.onNavClick;
        // One day
        //<div className="icon-button" onClick={this.handleSettings.bind(this)}>
        //  <SvgIcon className="not-implemented" svg={require('../../icons/full-settings.svg')}/>
        //</div>
        var userButton = null;
        if (user) {
            userButton = <div className="icon-button">
        <svg_icon_1.SvgIcon svg={require('../../icons/full-user.svg')}/>
      </div>;
        }
        return <header className="home-header-bar">
      <div className="left-bar" onClick={onNavClick}>
        <div className="menu-icon">
          <svg_icon_1.SvgIcon svg={require('../../icons/menu.svg')}/>
        </div>
        <div className="title">Home</div>
      </div>
      <div className="right-bar">
        <a className="icon-button help" href="https://groups.google.com/forum/#!forum/imply-user-group" target="_blank">
          <svg_icon_1.SvgIcon className="help-icon" svg={require('../../icons/help.svg')}/>
        </a>
        <a className="icon-button github" href="https://github.com/implydata/pivot" target="_blank">
          <svg_icon_1.SvgIcon className="github-icon" svg={require('../../icons/github.svg')}/>
        </a>
        {userButton}
      </div>
    </header>;
    };
    return HomeHeaderBar;
}(React.Component));
exports.HomeHeaderBar = HomeHeaderBar;
//# sourceMappingURL=home-header-bar.js.map