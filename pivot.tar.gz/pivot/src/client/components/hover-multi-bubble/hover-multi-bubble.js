"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require('./hover-multi-bubble.css');
var React = require('react');
var constants_1 = require('../../config/constants');
var date_1 = require('../../utils/date/date');
var body_portal_1 = require('../body-portal/body-portal');
var LEFT_OFFSET = 22;
var HoverMultiBubble = (function (_super) {
    __extends(HoverMultiBubble, _super);
    function HoverMultiBubble() {
        _super.call(this);
        // this.state = {};
    }
    HoverMultiBubble.prototype.render = function () {
        var _a = this.props, essence = _a.essence, datums = _a.datums, measure = _a.measure, getY = _a.getY, left = _a.left, top = _a.top;
        var colors = essence.colors;
        var existingDatum = datums.filter(Boolean)[0];
        if (!datums || !existingDatum || !colors)
            return null;
        var colorSwabs = datums.map(function (datum, i) {
            if (!datum)
                return null;
            var segmentValue = datum[constants_1.SEGMENT];
            var segmentValueString = String(segmentValue);
            var segmentMeasure = getY(datum);
            var swabStyle = { background: colors.getColor(segmentValue, i) };
            return <div className="color" key={segmentValueString}>
        <div className="color-swab" style={swabStyle}></div>
        <div className="color-name">{segmentValueString}</div>
        <div className="color-value">{measure.formatFn(segmentMeasure)}</div>
      </div>;
        });
        return <body_portal_1.BodyPortal left={left + LEFT_OFFSET} top={top} disablePointerEvents={true}>
      <div className="hover-multi-bubble">
        <div className="bucket">{date_1.formatTimeRange(existingDatum[constants_1.TIME_SEGMENT], essence.timezone, date_1.DisplayYear.NEVER)}</div>
        <div className="colors">{colorSwabs}</div>
      </div>
    </body_portal_1.BodyPortal>;
    };
    return HoverMultiBubble;
}(React.Component));
exports.HoverMultiBubble = HoverMultiBubble;
//# sourceMappingURL=hover-multi-bubble.js.map